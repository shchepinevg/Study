some_func <- function(x) {
  x[1]^2 + x[2]^2  
}

Rosenbrock_method_for_test <- function(N) {
  epsl = 0.001
  alpha = 3
  beta = -0.5
  d1 = c(1, 0)
  d2 = c(0, 1)
  step = c(1, 2)
  x.0 = c(8, 9)
  func <- some_func
  
  y.current <- x.0
  y.prev <- x.0
  x.current <- x.0
  x.prev <- x.0
  k <- 0
  l <- 0
  while (T) {
    if (func(y.current + step[1] * d1) < func(y.current)) {
      y.current = y.current + step[1] * d1
      step[1] = step[1] * alpha
    } else {
      step[1] = step[1] * beta
    }
    
    if (func(y.current + step[2] * d2) < func(y.current)) {
      y.current = y.current + step[2] * d2
      step[2] = step[2] * alpha
    } else {
      step[2] = step[2] * beta
    }
    
    if (func(y.current) < func(y.prev)) {
      y.prev <- y.current
      next
    }
    
    if ((func(y.current) < func(x.prev)) || 
        (all.equal(func(y.current), func(x.prev)) && l == N)) {
      
      x.current <- y.current
      if (sqrt((x.current[1] - x.prev[1])^2 + (x.current[2] - x.prev[2])^2) <= epsl) {
        return(k)
      } else {
        dx <- x.current - x.prev
        if (d1[1] == 0) {
          lamb2 = dx[1]/d2[1]
          lamb1 = (dx[2] - lamb2*d2[2]) / d1[2]
        }
        else if (d2[1] == 0) {
          lamb1 = dx[1]/d1[1]
          lamb2 = (dx[2] - lamb1*d1[2]) / d2[2]
        }
        else {
          lamb2 = (d1[1]*dx[2] - d1[2]*dx[1]) / (d1[1]*d2[2] - d1[2]*d2[1])
          lamb1 = (dx[1] - lamb2*d2[1]) / d1[1]
        }
        if (lamb1 != 0)
          b1 = lamb1*d1 + lamb2*d2
        else b1 = d1
        d1 = b1 / sqrt(b1[1]^2 + b1[2]^2)
        if (lamb2 != 0)
          a2 = lamb2*d2
        else a2 = d2
        b2 = a2 - d1*(a2[1]*d1[1] + a2[2]*d1[2])
        d2 = b2 / sqrt(b2[1]^2 + b2[2]^2)
        k <- k + 1
        l <- 0
        x.prev <- x.current
        y.prev <- x.current
        next
      }
    } else if (abs(step[1]) <= epsl && abs(step[2]) <= epsl) {
      return(k)
    } else {
      y.prev <- y.current
      l <- l + 1
      next
    }
  }
}

test.k.epsl <- function() {
  mas.epsl <- c(0.1, 0.01, 0.001, 0.0001, 0.00001)
  newmas <- Rosenbrock_method_for_test(mas.epsl)
  mas.k <- sapply(mas.epsl, Rosenbrock_method_for_test)
  plot(mas.epsl, mas.k, xlim = c(0, 0.1), xlab = "epsl", ylab = "k", type = "s",
       main = "����������� k �� ����� epsl")
}

test.k.epsl <- function(epsl) {
  return(Rosenbrock_method_for_test(c(8, 9), epsl, 3, -0.5, c(1, 0),
                                    c(0, 1), c(1, 2), 3, some_func))
}

plot(Vectorize(test.k.epsl), xlim = c(0, 0.1), xlab = "epsl", ylab = "k", type = "s",
     main = "����������� k �� ����� epsl")

#
test.k.epsl <- function() {
  mas.N <- c(1, 2, 3, 4, 5, 6, 7, 8)
  newmas <- Rosenbrock_method_for_test(mas.N)
  mas.k <- sapply(mas.N, Rosenbrock_method_for_test)
  plot(mas.N, mas.k, xlim = c(1, 8), xlab = "N", ylab = "k", type = "s",
       main = "����������� k �� N")
}

#
test.k.x0 <- function() {
  mas.x0 <- list(c(1, 1), c(2, 2), c(3, 3), c(4, 4), c(5, 5))
  newmas <- Rosenbrock_method_for_test(list)
  mas.k <- sapply(mas.x0, Rosenbrock_method_for_test)
  mas.dist <- sapply(mas.x0, dist)
  plot(mas.dist, mas.k, xlim = c(1, 8), xlab = "����������", ylab = "k", type = "s",
       main = "����������� k �� ���������� �� ��������� ����� �� ����� ��������")
}

dist <- function(x) {
  d <- sqrt(x[1]^2 + x[2]^2)
  return(d)
}

  