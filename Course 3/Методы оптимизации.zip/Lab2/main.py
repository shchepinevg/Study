import math
import matplotlib.pyplot as plt
import numpy as np

def function(x):
	return x**2 + 6*x + 12

def powell_method(x1, del_x, e1, e2):
	# шаг 2
	x2 = x1 + del_x

	# шаг 3
	f_x1 = function(x1)
	f_x2 = function(x2)

	# шаг 4
	if f_x1 > f_x2:
		x3 = x1 + 2*del_x
	else:
		x3 = x1 - del_x

	# шаг 5
	f_x3 = function(x3)

	# шаг 6
	while True:
		func_min = min(f_x1, f_x2, f_x3)
		if func_min == f_x1:
			x_min = x1
		elif func_min == f_x2:
			x_min = x2
		else:
			x_min = x3

		# шаг 7
		denominator = (x2 - x3)*f_x1 + (x3 - x1)*f_x2 + (x1 - x2)*f_x3

		if denominator == 0:
			x1 = x_min
			return powell_method(x1, del_x, e1, e2)

		numeration = (x2**2 - x3**2)*f_x1 + (x3**2 - x1**2)*f_x2 + (x1**2 - x2**2)*f_x3
		x_min_interpolyn = 1 / 2 * numeration / denominator

		c1 = 1
		a1 = func_min - function(x_min_interpolyn)
		b1 = function(x_min_interpolyn)
		try:
			c1 = math.fabs(a1 / b1)
		except ZeroDivisionError:
			print("Знаменатель равен нулю")
			exit()

		c2 = 1
		a2 = x_min - x_min_interpolyn
		b2 = x_min_interpolyn
		try:
			c2 = math.fabs(a2 / b2)
		except ZeroDivisionError:
			print("Знаменатель равен нулю")
			exit()

		list_x = [x1, x2, x3]
		list_x.sort()

		# шаг 8
		if c1 < e1 and c2 < e2:
			return x_min_interpolyn
		elif x_min_interpolyn >= list_x[0] and x_min_interpolyn <= list_x[2]:
			list_xx = [x1, x2, x3, x_min_interpolyn]
			list_xx.sort()
			index = list_xx.index(x_min_interpolyn)
			x2 = x_min_interpolyn
			x1 = list_xx[index - 1]
			x3 = list_xx[index + 1]
			f_x1 = function(x1)
			f_x2 = function(x2)
			f_x3 = function(x3)
		else:
			x1 = x_min_interpolyn
			return powell_method(x1, del_x, e1, e2)

# шаг 1
x1, del_x, e1, e2 = 0, 0, 0, 0
x1 = float(input("Введите начальную точку x1: "))
del_x = float(input("Введите велечину шага del_x: "))
print("Введите малые положительные числа e1, e2:")
e1 = float(input("e1 = "))
e2 = float(input("e2 = "))
x_min = float(powell_method(x1, del_x, e1, e2))
print("\nf(x) = x*x + 6*x + 12")
print("x_min = ", x_min)
print("f(x_min) = ", function(int(x_min)))

plt.xlabel("x")
plt.ylabel("f(x)")
x = np.linspace(-6, 6)
plt.plot(x, function(x))
plt.scatter(x_min, function(x_min), color='red')
plt.show()