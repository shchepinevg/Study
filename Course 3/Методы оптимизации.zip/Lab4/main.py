import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import copy

def func(point):
	'''2 * x1**2 - 2 * x2**2 + x1*x2 + 4 * x2**2'''
	#return 2*point.x1*point.x1 - 2*point.x2 + point.x1*point.x2 + 4*point.x2*point.x2
	return point.x2**2 + 6*point.x1**2 + (point.x1*5 + 2*point.x2**2) + 1
	#return x1**2 - 6*x2**2 - x1*x2 + 14

class Point:
	x1 = 0.0
	x2 = 0.0
	def __init__(self, x1, x2):
		self.x1 = x1
		self.x2 = x2

def printFig(x_min):
	fig = plt.figure()
	ax = fig.add_subplot(111, projection='3d')
	x = np.linspace(-6, 6, 10)
	y = np.linspace(-6, 6, 10)
	x, y = np.meshgrid(x, y)
	#z = 2*x**2 - 2*y + x*y + 4*y**2
	z = y**2 + 6*x**2 + (5*x + 2*y**2) + 1
	ax.plot_wireframe(x, y, z)
	ax.scatter(x_min.x1, x_min.x2, func(x_min), color='red')
	plt.show()

# param: 
#		alpha - отражения, beta - сжатия, 
# 		gamma - растяжения, epsl - параметр остановки алгоритма, 
#		l - координаты вершин многогранника
def startNM(alpha, beta, gamma, epsl, l):
	list_p = copy.deepcopy(l)
	k = 0
	while True:
		k += 1
		list_p.sort(key=func)

		# x_l - наилучшая, x_h - наихудшая, x_g - второе по величине после x_h
		x_l = list_p[0]
		x_g = list_p[len(list_p) - 2]
		x_h = list_p[len(list_p) - 1]

		sum_x1 = 0.0
		sum_x2 = 0.0
		for p in list_p:
			sum_x1 += p.x1
			sum_x2 += p.x2

		# x_c - центр тяжести
		x_c = Point(0.0, 0.0)
		x_c.x1 = (sum_x1 - x_h.x1) / (len(list_p) - 1)
		x_c.x2 = (sum_x2 - x_h.x2) / (len(list_p) - 1)

		sum_f = 0.0
		for p in list_p:
			sum_f += (func(p) - func(x_c))**2
		sigma = (sum_f / len(list_p))**0.5

		if sigma <= epsl:
			print("Количесиво итераций: ", k)
			return x_l

		# x_r - точка отражения x_h через x_c (операциия отражения)
		x_r = Point(0.0, 0.0)
		x_r.x1 = x_c.x1 + alpha * (x_c.x1 - x_h.x1)
		x_r.x2 = x_c.x2 + alpha * (x_c.x2 - x_h.x2)

		# x_e - точка получившаяся после растяжения (операция растяжения)
		if func(x_r) < func(x_l):
			x_e = Point(0.0, 0.0)
			x_e.x1 = x_c.x1 + gamma * (x_r.x1 - x_c.x1)
			x_e.x2 = x_c.x2 + gamma * (x_r.x2 - x_c.x2)

			if func(x_e) < func(x_l):
				list_p[len(list_p) - 1] = x_e
			else:
				list_p[len(list_p) - 1] = x_r
			continue

		# x_compression - точка получившаяся после сжатия (операция сжатия)
		if func(x_g) < func(x_r) <= func(x_h):
			x_compression = Point(0.0, 0.0)
			x_compression.x1 = x_c.x1 + beta * (x_h.x1 - x_c.x1)
			x_compression.x2 = x_c.x2 + beta * (x_h.x2 - x_c.x2)
			list_p[len(list_p) - 1] = x_compression
			continue

		if func(x_l) < func(x_r) <= func(x_g):
			list_p[len(list_p) - 1] = x_r
			continue

		# операция редукции
		if func(x_r) > func(x_h):
			new_list_p = []
			for p in list_p:
				p.x1 = x_l.x1 + 0.5 * (p.x1 - x_l.x1)
				p.x2 = x_l.x2 + 0.5 * (p.x2 - x_l.x2)
				new_list_p.append(p)
			list_p = new_list_p

x_min = Point(0.0, 0.0)
list_p = [Point(-3.0, -3.0), Point(-3.0, 3.0), Point(3.0, 3.0)]
epsl = float(input("epsl: "))
#param: alpha, beta, gamma, epsl, l
x_min = startNM(1, 0.5, 3, epsl, list_p)
print("x1: ", x_min.x1)
print("x2: ", x_min.x2)
print("f(x_min): ", func(x_min))
printFig(x_min)