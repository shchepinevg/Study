def fibonacci_method():
	# шаг 1
	l = float(input("Введите допустимую длину конечного интервала (l): "));
	e = float(input("Введите константу различимости (e): "));
	a, b = 0, 1
	interval = lambda: b - a

	# шаг 2
	value = interval() / l
	fibonacci = get_fibonacci(value)
	N = len(fibonacci)

	# шаг 3
	k = 0

	# шаг 4
	Nth = N - 1
	y = a + (fibonacci[Nth - 2] / fibonacci[Nth]) * interval()
	z = a + (fibonacci[Nth - 1] / fibonacci[Nth]) * interval()

	for k in range(0, Nth - 3):
		# шаг 5
		func_y = function(y)
		func_z = function(z)

		# шаг 6
		if func_y <= func_z:
			b = z
			z = y
			y = a + (fibonacci[Nth - k - 3] / fibonacci[Nth - k - 1]) * interval() 
		else:
			a = y
			y = z
			z = a + (fibonacci[Nth - k - 2] / fibonacci[Nth - k - 1]) * interval()

	# шаг 7
	y = z
	z = y + e

	func_y = function(y)
	func_z = function(z)

	if func_y <= func_z:
		b = z
	else:
		a = y

	x = (a + b) / 2

	return x

def get_fibonacci(value):
    fibonacci = [1, 1]
    last_index = 1
    get_next = lambda: fibonacci[last_index] + fibonacci[last_index - 1]

    while not fibonacci[last_index] >= value:
        fibonacci.append(get_next())
        last_index += 1
    
    return fibonacci

def function(x):
	return -39*x**3 + 35*x**2 + 215*x -51

x = fibonacci_method()
print("\nf(x) = x*x + 6*x + 12")
print("x_min = ", x)
print("f(x_min) = ", function(x))