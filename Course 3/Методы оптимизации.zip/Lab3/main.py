import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import copy

class Point:
	x1 = 0
	x2 = 0
	def __init__(self, x1, x2):
		self.x1 = x1
		self.x2 = x2

def func(x1, x2):
	return 2*x1*x1 - 2*x2 + x1*x2 + 4*x2*x2
	#return x1**2 - 6*x2**2 - x1*x2 + 14

def printFig(point_min, flag):
	fig = plt.figure()
	ax = fig.add_subplot(111, projection='3d')
	x = np.linspace(-6, 6, 10)
	y = np.linspace(-6, 6, 10)
	x, y = np.meshgrid(x, y)
	z = func(x, y)
	#ax.plot_surface(x, y, z)
	ax.plot_wireframe(x, y, z)
	if flag == 1:
		ax.scatter(point_min.x1, point_min.x2, func(point_min.x1, point_min.x2), c='r', marker='o')
	plt.show()

def startHJ(x1, x2, e, d, lam, a):
	point = Point(x1, x2)
	prev = copy.deepcopy(point)
	k = 0
	t = 0

	while True:
		k = k + 1
		if func(point.x1 + d, point.x2) < func(point.x1, point.x2):
			point.x1 += d
		elif func(point.x1 - d, point.x2) < func(point.x1, point.x2):
			point.x1 -= d

		if func(point.x1, point.x2 + d) < func(point.x1, point.x2):
			point.x2 += d
		elif func(point.x1, point.x2 - d) < func(point.x1, point.x2):
			point.x2 -= d

		if func(point.x1, point.x2) < func(prev.x1, prev.x2):
			temp = copy.deepcopy(point)
			point.x1 = point.x1 + lam * (point.x1 - prev.x1)
			point.x2 = point.x2 + lam * (point.x2 - prev.x2)
			prev = temp
		elif d <= e:
			print("Количесиво итераций: ", k)
			return point
		else:
			d /= a
			t = 1
			prev = copy.deepcopy(point)

		if k > 100 and t == 0:
			printFig(point, 0)
			raise Exception("Нет точки минимума")

epsl = float(input("epsl: "))
# param: x1, x2, e, d, lam, a
point_min = startHJ(0, 0, epsl, 0.01, 0.1, 1.2)
print("x1_min: ", point_min.x1)
print("x2_min: ", point_min.x2)
print("f(x_min): ", func(point_min.x1, point_min.x2))
printFig(point_min, 1)