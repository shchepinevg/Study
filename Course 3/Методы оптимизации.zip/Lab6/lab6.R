#rm(list = ls())
   
fn <- function(x) {
  #return(2*x[1]^2 - 2*x[2] + x[1]*x[2] + 4*x[2]^2)
  return((x[1] - 3)^2 + (x[2] + 5)^2)
}

printFunc <- function(x.min, func) {
  x <- -6:6
  y <- -6:6
  zfunc <- function(x, y) {
    return(2*x^2 - 2*y + x*y + 4*y^2)
  }
  z <- outer(x, y, FUN = "zfunc")
  x.1 <- as.character(round(x.min[1], digits = 5))
  x.2 <- as.character(round(x.min[2], digits = 5))
  x.3 <- as.character(round(func(x.min), digits = 5))
  info <- paste("x =", x.1, "y =", x.2, "z =", x.3)
  persp3d(x, y, z, col = "skyblue", sub = info)
  points3d(x.min[1], x.min[2], func(x.min), col = "red", size = 15)
}

Powell_method <- function(x.0, epsl, func) {
  # Args:
  #   x.0: ��������� ����� (������)
  #   elsp: ����� ��� ��������� ��������� (numeric)
  #   func: ������� � ������� ������ �������
  # 
  # Returns:
  #   ������� ������� (������)
  d.1 <- c(1, 0)
  d.2 <- c(0, 1)
  k <- 0
  d.0 <- d.2
  y.0 <- y.1 <- y.2 <- y.3 <- x.0
  x.prev <- x.0
  x.next <- x.0
  
  while (T) {
    k <- k + 1
    
    temp.func <- function(t) {
      func(y.0 + t * d.0)
    }
    t <- nlm(temp.func, 0)$estimate
    #t <- fibonacci(temp.func)
    y.1 <- y.0 + t * d.0
    
    temp.func <- function(t) {
      func(y.1 + t * d.1)
    }
    t <- nlm(temp.func, 0)$estimate
    #t <- fibonacci(temp.func)
    y.2 <- y.1 + t * d.1
    
    if (all.equal(y.2, y.0) == TRUE) {
      return(y.2)
    }
    
    temp.func <- function(t) {
      func(y.2 + t * d.2)
    }
    t <- nlm(temp.func, 0)$estimate
    #t <- fibonacci(temp.func)
    y.3 <- y.2 + t * d.2
    
    if (all.equal(y.3, y.1) == TRUE) {
      return(y.3)
    }
    
    x.next <- y.3
    if (sqrt((x.next[1] - x.prev[1])^2 + (x.next[2] - x.prev[2])^2) < epsl) {
      return(x.next)
    }
    
    if (d.2[1] * (y.3 - y.1)[2] != d.2[2] * (y.3 - y.1)[1]) {
      d.1 <- d.2
      d.0 <- d.2 <- y.3 - y.1
    }
    y.0 <- x.next
    x.prev <- x.next
  }
}

x.min <- Powell_method(c(8, 9), 0.001, fn)
printFunc(x.min, fn)


