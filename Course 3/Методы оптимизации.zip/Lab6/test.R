Powell_method_for_test <- function(epsl) {
  x.0 = c(8, 9)
  func = fn
  d.1 <- c(1, 0)
  d.2 <- c(0, 1)
  k <- 0
  d.0 <- d.2
  y.0 <- y.1 <- y.2 <- y.3 <- x.0
  x.current <- x.0
  x.next <- x.0
  
  while (T) {
    k <- k + 1
    
    temp.func <- function(t) {
      func(y.0 + t * d.0)
    }
    t <- nlm(temp.func, 0)$estimate
    y.1 <- y.0 + t * d.0
    
    temp.func <- function(t) {
      func(y.1 + t * d.1)
    }
    t <- nlm(temp.func, 0)$estimate
    y.2 <- y.1 + t * d.1
    
    if (all.equal(y.2, y.0) == TRUE) {
      return(k)
    }
    
    temp.func <- function(t) {
      func(y.2 + t * d.2)
    }
    t <- nlm(temp.func, 0)$estimate
    y.3 <- y.2 + t * d.2
    
    if (all.equal(y.3, y.1) == TRUE) {
      return(k)
    }
    
    x.next <- y.3
    if (sqrt((x.next[1] - x.current[1])^2 + (x.next[2] - x.current[2])^2) < epsl) {
      return(k)
    }
    
    if (d.2[1] * (y.3 - y.1)[2] != d.2[2] * (y.3 - y.1)[1]) {
      d.1 <- d.2
      d.0 <- d.2 <- y.3 - y.1
    }
    y.0 <- x.next
    x.prev <- x.next
  }
}

test.epsl <- function() {
  mas.epsl <- seq(0.0001, 0.1, 0.005)
  mas.k <- sapply(mas.epsl, Powell_method_for_test)
  plot(mas.epsl, mas.k, main = "����������� epsl �� k", 
       xlab = "epsl", ylab = "k", xlim = c(0, 0.1), type = "l")
}

test.dist <- function() {
  mas.x0 <- list(c(1, 1), c(2, 2), c(3, 3), c(4, 4), c(5, 5))
  mas.k <- sapply(mas.x0, Powell_method_for_test)
  mas.dist <- sapply(mas.x0, dist)
  plot(mas.dist, mas.k, main = "����������� dist �� k", 
       xlab = "dist", ylab = "k", type = "l")
}

dist <- function(x) {
  d <- sqrt(x[1]^2 + x[2]^2)
  return(d)
}

test.epsl()
test.dist()

