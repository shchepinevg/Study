fibonacci = function(f, n = 0) {
  a <- -6
  b <- 6
  l <- 0.1
  eps <- 0.1
  
  fibnums = c(1,1)
  i = 2
  while (fibnums[i] < (abs(b-a)/l)) {
    fibnums = c(fibnums, fibnums[i]+fibnums[i-1])
    i = i+1
  }
  if (n < i)
    n = i
  
  k = 0
  y = a + (fibnums[n-2] / fibnums [n]) * (b-a)
  z = a + (fibnums[n-1] / fibnums[n]) * (b-a)
  while(k != (n-3)) {
    if (f(y) <= f(z)) {
      b = z
      z = y
      y = a + (fibnums[n-k-3] / fibnums[n-k-1]) * (b-a)
    } else {
      a = y
      y = z
      z = a + (fibnums[n-k-2] / fibnums[n-k-1]) * (b-a)
    }
    k = k+1
  }
  y = (a+b)/2
  z = y + eps
  if (f(y) <= f(z))
    b = z
  else 
    a = y 
  xmin = (a+b)/2
  
  return(xmin)
}
