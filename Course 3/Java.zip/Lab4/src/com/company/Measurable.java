package com.company;

public interface Measurable {
    double getMeasure();
}
