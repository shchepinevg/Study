package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String menu;
        Measurable[] employees = new Employee[5];
        employees[0] = new Employee("Александр", 90000);
        employees[1] = new Employee("Борис", 25000);
        employees[2] = new Employee("Василий", 8000);
        employees[3] = new Employee("Дмитрий", 150000);
        employees[4] = new Employee("Константин", 50000);

        do {
            printMenu();
            menu = in.nextLine();

            switch (menu) {
                case "1":
                    employees = Arrays.copyOf(employees, employees.length + 1);
                    employees[employees.length - 1] = Employee.addEmployee();
                    break;

                case "2":
                    if (employees.length > 0) {
                        int i = 1;
                        for (Measurable employee : employees) {
                            System.out.print(i + ") ");
                            ((Employee) employee).showEmployee();
                            i++;
                        }
                    } else {
                        System.out.println("Список работников пуст.");
                        break;
                    }

                    int t;
                    while (true) {
                        System.out.println("Выберите номер работника которого хотите удалить:");
                        t = in.nextInt();
                        in.nextLine();

                        if (t <= 0 || t > employees.length) {
                            System.out.println("Работника с таким номером не существует");
                        } else {
                            employees = removeElement(employees, t);
                            System.out.println("Работник удален");
                            break;
                        }
                    }
                    break;

                case "3":
                    if (employees.length > 0) {
                        int i = 1;
                        for (Measurable employee : employees) {
                            System.out.print(i + ") ");
                            ((Employee) employee).showEmployee();
                            i++;
                        }
                    } else
                        System.out.println("Список работников пуст.");
                    break;

                case "4":
                    if (employees.length > 0) {
                        System.out.println("Средняя зарплата: " + Employee.average(employees));
                    } else
                        System.out.println("Список работников пуст.");
                    break;

                case "5":
                    if (employees.length > 0) {
                        ((Employee) Employee.largest(employees)).showEmployee();
                    } else
                        System.out.println("Список работников пуст.");
                    break;

                case "0":
                    break;

                default:
                    System.out.println("Такого пункта меню не существует");
                    break;
            }

        } while (!menu.equals("0"));
    }

    public static void printMenu() {
        System.out.println("\nВыберите пункт меню");
        System.out.println("1: Добавить работника");
        System.out.println("2: Удалить работника");
        System.out.println("3: Показать список всех работников");
        System.out.println("4: Показать среднюю зарплату работников");
        System.out.println("5: Показать работника с самой высокой зарплатой");
        System.out.println("0: Выход");
    }

    public static Measurable[] removeElement(Measurable[] original, int element) {
        element--;
        Measurable[] n = new Employee[original.length - 1];
        System.arraycopy(original, 0, n, 0, element );
        System.arraycopy(original, element+1, n, element, original.length - element-1);
        return n;
    }
}
