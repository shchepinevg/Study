package com.company;

import java.util.Scanner;

public class Employee implements Measurable {
    private String name;
    private int salary;

    public Employee(String name, int salary) {
        if (name.trim().isEmpty())
            throw new IllegalArgumentException("Имя не может быть пустым.");

        if (salary < 0)
            throw new IllegalArgumentException("Зарплата не может быть меньше 0.");

        this.name = name;
        this.salary = salary;
    }

    public static Employee addEmployee() {
        Scanner in = new Scanner(System.in);
        String name;
        int salary;

        while (true) {
            System.out.println("Введите имя работника:");
            name = in.nextLine().trim();
            if (name.trim().isEmpty()) {
                System.out.println("Имя не может быть пустым!");
            } else {
                break;
            }
        }

        do {
            System.out.println("Введите зарплату:");
            while (!in.hasNextInt()) {
                System.out.println("Некорректный ввод!");
                in.next();
            }
            salary = in.nextInt();

            if (salary < 0) {
                System.out.println("Зарплата не может быть отрицательной");
            }
        } while (salary < 0);

        return new Employee(name, salary);
    }

    public double getMeasure() {
        return salary;
    }

    public static double average(Measurable[] objects) {
        double sum = 0;

        for (Measurable object : objects) {
            sum += object.getMeasure();
        }

        return sum / objects.length;
    }

    public static Measurable largest(Measurable[] objects) {
        Measurable largest = objects[0];

        for (Measurable object : objects) {
            if (object.getMeasure() > largest.getMeasure())
                largest = object;
        }

        return largest;
    }

    public void showEmployee() {
        System.out.println("Имя: " + name + "\n   Зарплата: " + salary);
    }
}
