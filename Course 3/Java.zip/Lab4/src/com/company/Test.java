package com.company;

import java.util.Scanner;
import java.lang.Object;

public class Test {
    public static void main(String[] args) {
//      Scanner in = new Scanner(System.in);
//      int a = 0;
//      String s;
//
//      in.hasNextInt();
//      System.out.println("qwe");
//      a = in.nextInt();
//      System.out.println(a);

        int[] mas = new int[10];
        for (int i = 0; i < 10; i ++) {
            mas[i] = i + 1;
        }


    }
}
