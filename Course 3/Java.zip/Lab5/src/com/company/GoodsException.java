package com.company;

public class GoodsException extends Exception {
    private int year;
    public int getYear() { return year; }

    public GoodsException(String ms, int year) {
        super(ms);
        this.year = year;
    }
}
