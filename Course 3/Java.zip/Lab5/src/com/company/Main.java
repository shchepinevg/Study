package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int menu;
        Goods goods = new Goods();
        Scanner scanner = new Scanner(System.in);

        do {
            printMenu();
            menu = Integer.parseInt(scanner.next());

            switch (menu){
                case 1:
                    try {
                        goods.initialize();
                    } catch (GoodsException ge) {
                        System.out.println(ge.getMessage());
                        System.out.println("Вы ввели " + ge.getYear() + " год");
                    }
                    break;

                case 2:
                    goods.printInfo();
                    break;

                case 3:
                    try {
                        System.out.print("Введите год: ");
                        int productionYear = Integer.parseInt(scanner.next());
                        goods.compareProductionYear(productionYear);
                    } catch (GoodsException ge) {
                        System.out.println(ge.getMessage());
                        System.out.println("Вы ввели " + ge.getYear() + " год");
                    }
                    break;

                case 4:
                    System.out.print("Введите название: ");
                    scanner.nextLine();
                    String name = scanner.nextLine();
                    goods.compareName(name);
                    break;

                case 5:
                    try {
                        Goods goods2 = new Goods(goods);
                        goods.printInfo();
                        System.out.println("--------------------------");
                        goods2.printInfo();
                    } catch (GoodsException ge) {
                        System.out.println(ge.getMessage());
                        System.out.println("Вы ввели " + ge.getYear() + " год");
                    }
                    break;

                case 0:
                    break;
                default:
                    System.out.println("Такого пункта меню нет");
                    break;
            }

        }while(menu != 0);
    }

    public static void printMenu(){
        System.out.println("1) Ввести данные о товаре");
        System.out.println("2) Вывод данных о товаре");
        System.out.println("3) Определить относится ли год производства товара к введенному году");
        System.out.println("4) Определить совпадает ли название товара с введенной строкой");
        System.out.println("5) Скопировать товар");
        System.out.println("0) Выход");
        System.out.println("------------------------------");
    }
}
