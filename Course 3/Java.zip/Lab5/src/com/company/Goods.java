package com.company;

import java.util.Scanner;

public class Goods {
    private String name;
    private int productionYear;

    public Goods(){
        name = "Tovar";
        productionYear = 0;
    }

    public Goods(String name, int productionYear) throws GoodsException{
        if (name == null || name.trim().isEmpty()) {
            throw new RuntimeException("Строка не может быть пустой");
        }
        if (productionYear < 0) {
            throw new GoodsException("Год не может быть отрицательным", productionYear);
        }
        this.name = name;
        this.productionYear = productionYear;
    }

    public Goods(Goods goods) throws GoodsException{
        this(goods.name, goods.productionYear);
    }

    public void initialize() throws GoodsException{
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите название товара: ");
        this.name = scanner.nextLine();
        if (this.name == null || this.name.trim().isEmpty()) {
            throw new RuntimeException("Строка не может быть пустой");
        }

        System.out.print("Введите год производства товара: ");
        this.productionYear = Integer.parseInt(scanner.next());
        if (this.productionYear < 0) {
            throw new GoodsException("Год не может быть отрицательным", this.productionYear);
        }
    }

    public void printInfo(){
        System.out.println("Название товара: " + this.name);
        System.out.println("Год производства: " + this.productionYear);
        System.out.println();
    }

    public void compareProductionYear(int productionYear) throws GoodsException {
        if (productionYear < 0) {
            throw new GoodsException("Год не может быть отрицательным", productionYear);
        }

        if (this.productionYear == productionYear)
            System.out.println("Да, данный товар был произведен в этом году");
        else
            System.out.println("Нет, данный товар был произведен в другом году");
    }

    public void compareName(String name){
        if (name == null || name.trim().isEmpty()) {
            throw new RuntimeException("Строка не может быть пустой");
        }

        if (this.name.equals(name))
            System.out.println("Наименование товара совпадает с введенным вами названием");
        else
            System.out.println("Наименование товара НЕ совпадает с введенным вами названием");
    }
}
