package com.company;

public class UserDate {
    private int day = 0;
    private int month = 0;
    private int year = 0;

    public void setDay(int day){
        this.day = day;
    }

    public void setMonth(int month){
        this.month = month;
    }

    public void setYear(int year){
        this.year = year;
    }

    public int getDay(){ return day; }

    public int getMonth(){ return month; }

    public int getYear() { return year; }


    // Метод нахождения дня недели
    public String weekday(){
        String days[] = {"Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"};
        int a = (14 - month) / 12, y = year - a, m = month + 12 * a - 2;
        return days[(day + y + y / 4 - y / 100 + y / 400 + (31 * m) / 12) % 7];
    }
}
