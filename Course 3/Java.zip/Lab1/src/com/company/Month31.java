package com.company;

public enum Month31 {
    JANUARY(1),
    MARCH(3),
    MAY(5),
    JULY(7),
    AUGUST(8),
    OCTOBER(10),
    DECEMBER(12);

    private int index;

    Month31(int index){
        this.index = index;
    }

    public int getIndex(){
        return index;
    }
}
