package com.company;

public enum Month30 {
    APRIL(4),
    JUNE(6),
    SEPTEMBER(9),
    NOVEMBER(11);

    private int index;

    Month30(int index){
        this.index = index;
    }

    public int getIndex(){
        return index;
    }
}
