package com.company;

import java.util.Scanner;

public class Main {

    public static Scanner in = new Scanner(System.in);
    public static final int[] dLIMIT = {1, 28, 29, 30, 31};
    public static final int[] mLIMIT = {1, 12};
    public static final int[] yLIMIT = {1601, 2018};

    public static void main(String[] args) {
        int menu;
        UserDate userDate = new UserDate();
        do{
            System.out.println("Введите дату (ДД.ММ.ГГГГ): ");
            String date = in.nextLine();

            boolean check = tryParseToDate(date, userDate);

            if (check == false){
                System.out.println("Некорректная дата");
            }
            else {
                System.out.println("Это " + userDate.weekday());
            }

            menu = menuSelection();

        } while(menu == 1);
    }

    // Метод проверки корректности введенной даты (false - дата некорректна, true - дата корректна)
    public static boolean tryParseToDate(String date, UserDate userDate){
        if (date.length() != 10)
            return false;
        if (date.charAt(2) != '.' || date.charAt(5) != '.')
            return false;

        try{
            userDate.setDay(Integer.parseInt(date.substring(0, 2)));
            userDate.setMonth(Integer.parseInt(date.substring(3, 5)));
            userDate.setYear(Integer.parseInt(date.substring(6)));
        }
        catch (Exception e){
            return false;
        }

        //yLIMIT[0] = 1601, yLIMIT[1] = 2018
        if (userDate.getYear() < yLIMIT[0] || userDate.getYear() > yLIMIT[1])
            return false;

        //mLIMIT[0] = 1, mLIMIT[1] = 12
        if (userDate.getMonth() < mLIMIT[0] || userDate.getMonth() > mLIMIT[1])
            return false;

        //dLIMIT[0] = 1, dLIMIT[3] = 30
        for (Month30 m: Month30.values()){
            if (m.getIndex() == userDate.getMonth())
                if(userDate.getDay() < dLIMIT[0] || userDate.getDay() > dLIMIT[3])
                    return false;
        }

        //dLIMIT[0] = 1, dLIMIT[4] = 31
        for (Month31 m: Month31.values()){
            if (m.getIndex() == userDate.getMonth())
                if(userDate.getDay() < dLIMIT[0] || userDate.getDay() > dLIMIT[4])
                    return false;
        }

        //dLIMIT[0] = 1, dLIMIT[2] = 29, dLIMIT[1] = 28
        if (userDate.getMonth() == 2){
            if ((userDate.getYear() % 4 == 0) && userDate.getYear() != 1700
                    && userDate.getYear() != 1800 && userDate.getYear() != 1900){
                if (userDate.getDay() < dLIMIT[0] || userDate.getDay() > dLIMIT[2])
                    return false;
            }
            else{
                if (userDate.getDay() < dLIMIT[0] || userDate.getDay() > dLIMIT[1])
                    return false;
            }
        }

        return true;
    }

    // Метод вызова меню
    public static int menuSelection(){
        int menu;
        do {
            try {
                System.out.println("Повторить ввод даты?");
                System.out.println("1 - Да, 0 - Нет");
                menu = in.nextInt();
                in.nextLine();
                if (menu < 0 || menu > 1){
                    System.out.println("Выберите пункт меню (1/0)");
                    menu = -1;
                }
            } catch (Exception e) {
                in.nextLine();
                System.out.println("Некорректный ввод");
                menu = -1;
            }
        } while (menu == -1);
        return menu;
    }
}
