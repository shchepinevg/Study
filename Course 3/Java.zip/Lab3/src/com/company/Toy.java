package com.company;

import java.util.Objects;

public class Toy extends Goods {
    public String countryOfOrigin;

    public Toy(String name, String countryOfOrigin) {
        super(name);
        if (countryOfOrigin == null || countryOfOrigin.isEmpty())
            throw new IllegalArgumentException("Значение аргумента countryOfOrigin пустое");
        this.countryOfOrigin = countryOfOrigin;
    }

    @Override
    public String getInfo() {
        return "Информация о игрушке\n" +
                super.getInfo() +
                "Страна производства: " + countryOfOrigin + "\n";
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;

        Toy object = (Toy) obj;
        return countryOfOrigin.equals(object.countryOfOrigin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), countryOfOrigin.hashCode());
    }
}
