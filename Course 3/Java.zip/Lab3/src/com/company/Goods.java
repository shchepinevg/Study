package com.company;

public class Goods {
    private String name;

    public Goods(String name){
        if (name == null || name.isEmpty())
            throw new IllegalArgumentException("Значение аргумента name пустое");
        this.name = name;
    }

    public String getInfo(){
        return "Название: " + name + "\n";
    }

    @Override
    public boolean equals(Object obj){
        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (getClass() != obj.getClass())
            return false;

        Goods object = (Goods) obj;
        return name.equals(object.name);
    }

    @Override
    public int hashCode() {
        return 37*17 + name.hashCode();
    }
}
