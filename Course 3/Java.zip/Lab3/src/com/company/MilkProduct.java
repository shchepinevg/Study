package com.company;

import java.util.Objects;

public class MilkProduct extends Product {
    public int shelfLife;

    public MilkProduct(String name, int price, int shelfLife){
        super(name, price);
        if (shelfLife < 0){
            throw new IllegalArgumentException("Значение shelfLife отрицательное");
        }

        try {
            this.shelfLife = shelfLife;
        }
        catch (Exception e)
        {
            System.out.println("Некорректный ввод");
            System.exit(1);
        }
    }

    @Override
    public String getInfo() {
        return "Информация о молочном продукте\n" +
                super.getInfo() +
                "Срок годности: " + shelfLife + "д" + "\n";
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;

        return shelfLife == ((MilkProduct) obj).shelfLife;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), shelfLife);
    }
}
