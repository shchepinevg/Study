package com.company;

import java.util.Objects;

public class Product extends Goods {
    public int price;

    public Product (String name, int price) {
        super(name);
        if (price < 0)
            throw new IllegalArgumentException("Значение price отрицательное");

        try {
            this.price = price;
        }
        catch (Exception e)
        {
            System.out.println("Некорректный ввод");
            System.exit(1);
        }
    }

    @Override
    public String getInfo() {
        return super.getInfo() +
                "Цена: " + price + "р\n";
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;

        return price == ((Product) obj).price;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), price);
    }
}
