package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Goods> goods = new ArrayList<>();

        try {
            goods.add(new Toy("Машинка", "Германия"));
            goods.add(new MilkProduct("Молоко", 89, 30));
        }
        catch (Exception e) {
            System.out.println("Ошибка");
            System.exit(1);
        }

        String information;
        for (Goods g : goods) {
            information = g.getInfo() + "\n";
            System.out.println(information);
        }
    }
}