package com.company;

import java.util.Scanner;

public class Goods {
    private String name;
    private int productionYear;

    public Goods(){
        name = "";
        productionYear = 0;
    }

    public Goods(String name, int productionYear){
        if (name == null){
            throw new RuntimeException("Строка содержит null");
        }
        if (productionYear < 0){
            throw new RuntimeException("Год не может быть отрицательным");
        }
        this.name = name;
        this.productionYear = productionYear;
    }

    public Goods(Goods goods){
        this(goods.name, goods.productionYear);
    }

    public void initialize(){
        Read read = new Read();
        System.out.print("Введите название товара: ");
        this.name = read.readStr();
        System.out.print("Введите год производства товара: ");
        this.productionYear = read.readInt();
    }

    public void printInfo(){
        System.out.println("Название товара: " + this.name);
        System.out.println("Год производства: " + this.productionYear);
        System.out.println();
    }

    public void compareProductionYear(int productionYear){
        if (this.productionYear == productionYear)
            System.out.println("Да, данный товар был произведен в этом году");
        else
            System.out.println("Нет, данный товар был произведен в другом году");
    }

    public void compareName(String name){
        if (this.name.equals(name))
            System.out.println("Наименование товара совпадает с введенным вами названием");
        else
            System.out.println("Наименование товара НЕ совпадает с введенным вами названием");
    }

    public class Read {
        private Scanner in = new Scanner(System.in);

        public int readInt(){
            int value;
            do {
                try {
                    value = in.nextInt();
                    in.nextLine();
                    if (value < 0 || value > 2018){
                        System.out.println("Некорректный ввод");
                        value = -1;
                    }
                } catch (Exception e) {
                    in.nextLine();
                    System.out.println("Некорректный ввод");
                    value = -1;
                }
            } while (value == -1);
            return value;
        }

        public String readStr(){
            String str;
            do {
                str = in.nextLine();
                if (str.length() > 100)
                    System.out.println("Название товара должно быть меньше 100 символов");
            } while (str.length() > 100);

            return str;
        }
    }
}
