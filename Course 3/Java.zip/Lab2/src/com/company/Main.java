package com.company;

public class Main {

    public static void main(String[] args) {
        int menu;
        Goods goods = new Goods();
        Goods.Read read = goods.new Read();

        do{
            printMenu();
            menu = read.readInt();

            switch (menu){
                case 1:
                    goods.initialize();
                    break;
                case 2:
                    goods.printInfo();
                    break;
                case 3:
                    System.out.println("Введите год: ");
                    int productionYear = read.readInt();
                    goods.compareProductionYear(productionYear);
                    break;
                case 4:
                    System.out.println("Введите название: ");
                    String name = read.readStr();
                    goods.compareName(name);
                    break;
                case 5:
                    Goods goods2 = new Goods(goods);
                    goods.printInfo();
                    System.out.println("--------------------------");
                    goods2.printInfo();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Такого пункта меню нет");
                    break;
            }

        }while(menu != 0);
    }

    public static void printMenu(){
        System.out.println("1) Ввести данные о товаре");
        System.out.println("2) Вывод данных о товаре");
        System.out.println("3) Определить относится ли год производства товара к введенному году");
        System.out.println("4) Определить совпадает ли название товара с введенной строкой");
        System.out.println("5) Скопировать товар");
        System.out.println("0) Выход");
        System.out.println("------------------------------");
    }
}
