package com.company;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static Random rnd = new Random();

    public static void main(String[] args) {
        System.out.println("Введите количество стульев: ");
        int numberChairs = readInt();

        System.out.println("Введите время стрижки: ");
        int haircutTime = readInt();

        Semaphore semArmchair = new Semaphore(1, true);
        Semaphore semChairs = new Semaphore(numberChairs, true);

        int i = 1;
        System.out.println("Парикмахерская открывается, парикмахер пришел на рабочее место и уснул");
        while (true) {
            if (rnd.nextInt(2) == 1) {
                Customer customer = new Customer(semArmchair, semChairs, numberChairs, haircutTime, i);
                customer.start();
                i++;
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println("Ошибка");
            }
        }
    }

    private static int readInt(){
        int value;
        do {
            try {
                value = scanner.nextInt();
                scanner.nextLine();
                if (value < 1){
                    System.out.println("Некорректный ввод");
                    value = -1;
                }
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Некорректный ввод");
                value = -1;
            }
        } while (value == -1);
        return value;
    }
}
