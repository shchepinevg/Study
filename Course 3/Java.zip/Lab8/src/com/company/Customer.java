package com.company;

import java.util.concurrent.Semaphore;

public class Customer extends Thread {
    private Semaphore semArmchair;
    private Semaphore semChairs;
    private int numberChairs;
    private int haircutTime;
    private int number;
    private static int freeChairs = 0;
    private static boolean isSleeping = true;

    public Customer(Semaphore semArmchair, Semaphore semChairs, int numberChairs, int haircutTime, int number) {
        this.semArmchair = semArmchair;
        this.semChairs = semChairs;
        this.numberChairs = numberChairs;
        this.haircutTime = haircutTime;
        this.number = number;
    }

    @Override
    public void run() {
        try {
            if (freeChairs < numberChairs) {
                if (isSleeping) {
                    isSleeping = false;
                    System.out.println("Клиент " + number + " разбудил парикмахера");
                    semArmchair.acquire();
                    System.out.println("Клиент " + number + " занял кресло и начал подстригаться");
                    Thread.sleep(haircutTime * 1000);
                    System.out.println("Клиент " + number + " постригся и ушел");
                    semArmchair.release();
                    if (freeChairs == 0) {
                        isSleeping = true;
                        System.out.println("Парикмахер взглянул на пустые стулья и уснул");
                    }
                    return;
                }
                freeChairs++;
                semChairs.acquire();
                System.out.println("Клиент " + number + " занял стул");

                semArmchair.acquire();
                System.out.println("Клиент " + number + " занял кресло и начал подстригаться");
                semChairs.release();
                freeChairs--;
                Thread.sleep(haircutTime * 1000);

                System.out.println("Клиент " + number + " постригся и ушел");
                semArmchair.release();
            } else {
                System.out.println("Клиент " + number + " увидел большую очередь и ушел");
            }

        } catch (InterruptedException ex) {
            System.out.println("Ошибка");
        }

        if (freeChairs == 0) {
            isSleeping = true;
            System.out.println("Парикмахер взглянул на пустые стулья и уснул");
        }
    }
}
