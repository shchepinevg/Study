package com.company;

public class LinearList<T> {
    private Element listPointer = null;
    private Element topPointer = null;

    public Element getListPointer() {
        return listPointer;
    }

    public class Element {
        private T value;
        private Element pointer = null;
        private int number = 0;

        public int getNumber() {
            return number;
        }
    }

    // Проверить список на содержание
    public void isEmpty() {
        if (listPointer == null) {
            System.out.println("Список пустой");
        } else {
            System.out.println("Список не пустой");
        }
    }

    // Установить указатель в начало списка
    public void setTop() {
        if (listPointer != null) {
            listPointer = topPointer;
        } else {
            System.out.println("Список пустой");
        }
    }

    // Добавить элемент за указателем
    public void addElem(T value) {
        Element element = new Element();
        element.value = value;
        if (listPointer == null) {
            element.pointer = null;
            listPointer = element;
            topPointer = element;
        } else {
            element.pointer = listPointer.pointer;
            listPointer.pointer = element;
        }
        System.out.println("Элемент добавлен");
        numberList();
    }

    // Удалить элемент за указателем
    public void removeElem() {
        if (listPointer != null && listPointer.pointer != null) {
            listPointer.pointer = listPointer.pointer.pointer;
            numberList();
            System.out.println("Элемент удален");
        } else if (listPointer == null){
            System.out.println("Список пустой");
        } else {
            System.out.println("Нельзя удалить");
        }
    }

    // Просмотреть элемент за указателем
    public void showElem() {
        if (listPointer != null && listPointer.pointer != null) {
            System.out.println(listPointer.pointer.value);
        } else {
            System.out.println("Элемента нет");
        }
    }

    // Переместить указатель вправо
    public void moveRight() {
        if (listPointer != null && listPointer.pointer != null) {
            listPointer = listPointer.pointer;
        }
    }

    // Обменять значения конца списка и элемента за указателем
    public void swapLast() {
        if (listPointer != null && listPointer.pointer != null) {
            Element p = topPointer;
            while (p.pointer != null) {
                p = p.pointer;
            }
            T temp = listPointer.pointer.value;
            listPointer.pointer.value = p.value;
            p.value = temp;
        } else {
            System.out.println("Элемента для смены нет");
        }
    }

    // Обменять значения начала списка и элемента за указателем
    public void swapFirst() {
        if (listPointer != null && listPointer.pointer != null) {
            T temp = listPointer.pointer.value;
            listPointer.pointer.value = topPointer.value;
            topPointer.value = temp;
        } else {
            System.out.println("Элемента для смены нет");
        }
    }

    // Вывод списка на экран
    public void printList() {
        if (topPointer == null) {
            System.out.println("Список пустой");
            return;
        }

        Element p = topPointer;
        int i = 1;
        while (p != null) {
            System.out.println(i + ") " + p.value);
            i++;
            p = p.pointer;
        }
    }

    // Пронумеровать список
    private void numberList() {
        Element p = topPointer;
        int i = 1;
        while (p != null) {
            p.number = i;
            i++;
            p = p.pointer;
        }
    }
}
