package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int selectList, selectMenu;
        LinearList<Integer> listInt = new LinearList<>();
        LinearList<String> listStr = new LinearList<>();

        do {
            System.out.println("1) Работать с примитивными элементами");
            System.out.println("2) Работать с ссылочными элементами");
            System.out.println("0) Выход");

            try {
                selectList = Integer.parseInt(scanner.next());
            } catch (Exception ex) {
                System.out.println("Некоректный ввод");
                selectList = 1;
                continue;
            }

            if (selectList == 1 || selectList == 2) {
                do {
                    printMenu();
                    try {
                        selectMenu = Integer.parseInt(scanner.next());
                    } catch (Exception ex) {
                        System.out.println("Некоректный ввод");
                        selectMenu = 1;
                        continue;
                    }

                    switch (selectMenu) {
                        case 1:
                            if (selectList == 1) {
                                listInt.isEmpty();
                            } else {
                                listStr.isEmpty();
                            }
                            break;

                        case 2:
                            if (selectList == 1) {
                                listInt.setTop();
                            } else {
                                listStr.setTop();
                            }
                            break;

                        case 3:
                            if (selectList == 1) {
                                System.out.println("Введите число");
                                try {
                                    Integer value = Integer.parseInt(scanner.next());
                                    listInt.addElem(value);
                                } catch (Exception ex) {
                                    System.out.println("Некоректный ввод");
                                }
                            } else {
                                System.out.println("Введите строку");
                                scanner.nextLine();
                                String value = scanner.nextLine();
                                if (value == null || value.trim().isEmpty()) {
                                    throw new RuntimeException("Строка не может быть пустой");
                                }
                                listStr.addElem(value);
                            }
                            break;

                        case 4:
                            if (selectList == 1) {
                                listInt.removeElem();
                            } else {
                                listStr.removeElem();
                            }
                            break;

                        case 5:
                            if (selectList == 1) {
                                listInt.showElem();
                            } else {
                                listStr.showElem();
                            }
                            break;

                        case 6:
                            if (selectList == 1) {
                                listInt.moveRight();
                            } else {
                                listStr.moveRight();
                            }
                            break;

                        case 7:
                            if (selectList == 1) {
                                listInt.swapLast();
                            } else {
                                listStr.swapLast();
                            }
                            break;

                        case 8:
                            if (selectList == 1) {
                                listInt.swapFirst();
                            } else {
                                listStr.swapFirst();
                            }
                            break;

                        case 9:
                            if (selectList == 1 && listInt.getListPointer() != null) {
                                listInt.printList();
                                System.out.println("Указатель находится на " + listInt.getListPointer().getNumber() + " элементе");
                            } else if (selectList == 2 && listStr.getListPointer() != null){
                                listStr.printList();
                                System.out.println("Указатель находится на " + listStr.getListPointer().getNumber() + " элементе");
                            } else {
                                System.out.println("Список пустой");
                            }
                            break;

                        case 0:
                            break;
                        default:
                            System.out.println("Такого пункта меню нет");
                            break;
                    }

                } while(selectMenu != 0);
            }

        } while(selectList != 0);
    }

    private static void printMenu (){
        System.out.println("------------------------------");
        System.out.println("1) Проверить список на содержание");
        System.out.println("2) Установить указатель в начало списка");
        System.out.println("3) Добавить элемент за указателем");
        System.out.println("4) Удалить элемент за указателем");
        System.out.println("5) Просмотреть элемент за указателем");
        System.out.println("6) Переместить указатель вправо");
        System.out.println("7) Обменять значения конца списка и элемента за указателем");
        System.out.println("8) Обменять значения начала списка и элемента за указателем");
        System.out.println("9) Вывод списка на экран");
        System.out.println("0) Назад");
        System.out.println("------------------------------");
    }
}
