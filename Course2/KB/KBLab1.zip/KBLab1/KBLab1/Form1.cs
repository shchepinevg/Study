﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KBLab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.ActiveControl = textBox1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            textBox4.Clear();
            string openText = textBox1.Text;
            char[] encryptedStr = new char[openText.Length];
            int i1 = 0, j1 = 0, i2 = 0, j2 = 0;
            char lastChar = '\0';

            string keyword = textBox2.Text;
            Helper.GetNewKeyWord(ref keyword);

            Matrix matrix1 = new Matrix(keyword);

            keyword = textBox3.Text;
            Helper.GetNewKeyWord(ref keyword);

            Matrix matrix2 = new Matrix(keyword);
            
            if (openText.Length % 2 == 1)
            {
                lastChar = openText[openText.Length - 1];
                openText = openText.Remove(openText.Length - 1, 1);
                Array.Resize(ref encryptedStr, encryptedStr.Length - 1);
            }

            for (int i = 1; i <= openText.Length / 2; i++)
            {
                char firstChar = openText[i * 2 - 2];
                char secondChar = openText[i * 2 - 1];

                if (radioButton1.Checked)
                    Helper.GetIndexForEnc(ref i1, ref j1, ref i2, ref j2, matrix1, matrix2, firstChar, secondChar);

                if (radioButton2.Checked)
                    Helper.GetIndexForDec(ref i1, ref j1, ref i2, ref j2, matrix1, matrix2, firstChar, secondChar);
                
                if (j1 == j2)
                {
                    if (radioButton1.Checked)
                    {
                        encryptedStr[i * 2 - 2] = matrix2.GetMas()[i1, j2];
                        encryptedStr[i * 2 - 1] = matrix1.GetMas()[i2, j1];
                    }

                    if (radioButton2.Checked)
                    {
                        encryptedStr[i * 2 - 2] = matrix1.GetMas()[i1, j1];
                        encryptedStr[i * 2 - 1] = matrix2.GetMas()[i2, j2];
                    }
                }
                else
                {
                    if (radioButton1.Checked)
                    {
                        encryptedStr[i * 2 - 2] = matrix2.GetMas()[i2, j1];
                        encryptedStr[i * 2 - 1] = matrix1.GetMas()[i1, j2];
                    }

                    if (radioButton2.Checked)
                    {
                        encryptedStr[i * 2 - 2] = matrix1.GetMas()[i2, j1];
                        encryptedStr[i * 2 - 1] = matrix2.GetMas()[i1, j2];
                    }
                }
            }

            if (lastChar != '\0')
            {
                Array.Resize(ref encryptedStr, encryptedStr.Length + 1);
                encryptedStr[encryptedStr.Length - 1] = lastChar;
            }

            for (int i = 0; i < encryptedStr.Length; i++)
                textBox4.AppendText(Convert.ToString(encryptedStr[i]));
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if ((e.KeyChar < 97 || e.KeyChar > 122) && c != 32 && c != 8 && c != 44 && c != 45 && c != 46)
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if ((e.KeyChar < 97 || e.KeyChar > 122) && c != 8)
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if ((e.KeyChar < 97 || e.KeyChar > 122) && c != 8)
                e.Handled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox8.Text == "" || textBox7.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            textBox5.Clear();
            string openText = textBox8.Text;
            string finishText = textBox8.Text;

            int i1 = 0, j1 = 0, i2 = 0, j2 = 0, modI = 0, modJ = 0;

            string keyword = textBox7.Text;
            Helper.GetNewKeyWord(ref keyword);

            Matrix matrix1 = new Matrix(keyword);

            keyword = textBox6.Text;
            Helper.GetNewKeyWord(ref keyword);

            Matrix matrix2 = new Matrix(keyword);

            if (openText.Length % 3 == 1)
                openText += "  ";

            if (openText.Length % 3 == 2)
                openText += " ";

            char[] encryptedStr = new char[openText.Length];

            string key = textBox7.Text + textBox6.Text;
            Helper.GetNewKeyWord(ref key);

            Matrix modMatrix = new Matrix(key);

            for (int i = 1; i <= openText.Length / 3; i++)
            {
                char firstChar = openText[i * 3 - 3];
                char secondChar = openText[i * 3 - 2];
                char thirdChar = openText[i * 3 - 1];

                if (radioButton4.Checked)
                    Helper.GetIndexForEnc(ref i1, ref j1, ref i2, ref j2, ref modI, ref modJ, matrix1, matrix2, modMatrix, firstChar, secondChar, thirdChar);

                if (radioButton3.Checked)
                    Helper.GetIndexForDec(ref i1, ref j1, ref i2, ref j2, ref modI, ref modJ, matrix1, matrix2, modMatrix, firstChar, secondChar, thirdChar, i % 2 == 1);

                if (j1 == j2)
                {
                    if (radioButton4.Checked)
                    {
                        encryptedStr[i * 3 - 3] = modMatrix.GetMas()[i1, j2];
                        encryptedStr[i * 3 - 2] = modMatrix.GetMas()[i2, j1];
                        if (i % 2 == 1)
                            encryptedStr[i * 3 - 1] = matrix1.GetMas()[modI, modJ];
                        else
                            encryptedStr[i * 3 - 1] = matrix2.GetMas()[modI, modJ];
                    }

                    if (radioButton3.Checked)
                    {
                        encryptedStr[i * 3 - 3] = matrix1.GetMas()[i1, j1];
                        encryptedStr[i * 3 - 2] = matrix2.GetMas()[i2, j2];
                        encryptedStr[i * 3 - 1] = modMatrix.GetMas()[modI, modJ];
                    }
                }
                else
                {
                    if (radioButton4.Checked)
                    {
                        encryptedStr[i * 3 - 3] = modMatrix.GetMas()[i2, j1];
                        encryptedStr[i * 3 - 2] = modMatrix.GetMas()[i1, j2];
                        if (i % 2 == 1)
                            encryptedStr[i * 3 - 1] = matrix1.GetMas()[modI, modJ];
                        else
                            encryptedStr[i * 3 - 1] = matrix2.GetMas()[modI, modJ];
                    }

                    if (radioButton3.Checked)
                    {
                        encryptedStr[i * 3 - 3] = matrix1.GetMas()[i2, j1];
                        encryptedStr[i * 3 - 2] = matrix2.GetMas()[i1, j2];
                        encryptedStr[i * 3 - 1] = modMatrix.GetMas()[modI, modJ];
                    }
                }
            }

            for (int i = 0; i < encryptedStr.Length; i++)
                textBox5.AppendText(Convert.ToString(encryptedStr[i]));
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if ((e.KeyChar < 97 || e.KeyChar > 122) && c != 32 && c != 8 && c != 44 && c != 45 && c != 46)
                e.Handled = true;
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if ((e.KeyChar < 97 || e.KeyChar > 122) && c != 8)
                e.Handled = true;
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if ((e.KeyChar < 97 || e.KeyChar > 122) && c != 8)
                e.Handled = true;
        }
    }
}
