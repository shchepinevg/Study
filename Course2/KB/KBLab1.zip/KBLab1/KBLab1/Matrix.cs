﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KBLab1
{
    class Matrix
    {
        private char[,] mas = new char[6, 5];

        public char[,] GetMas()
        {
            return mas;
        }

        public Matrix(string keyword)
        {
            Helper helper = new Helper();
            int k = 0, t = 0; ;
            string str = helper.GetNewAlphabet(keyword);

            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 5; j++)
                {
                    if (k < keyword.Length)
                    {
                        mas[i, j] = keyword[k];
                        k++;
                    }
                    else
                    {
                        mas[i, j] = str[t];
                        t++;
                    }
                }
        }
    }
}
