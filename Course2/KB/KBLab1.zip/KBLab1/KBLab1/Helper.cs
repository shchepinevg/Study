﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KBLab1
{
    class Helper
    {
        private string alphabet = "abcdefghijklmnopqrstuvwxyz.,- ";

        public string GetNewAlphabet(string keyword)
        {
            for (int i = 0; i < keyword.Length; i++)
                for (int j = 0; j < alphabet.Length; j++)
                    if (alphabet[j] == keyword[i])
                    {
                        alphabet = alphabet.Remove(j, 1);
                        break;
                    }
            return alphabet;
        }

        public static void GetIndexForEnc(ref int i1, ref int j1, ref int i2, ref int j2, Matrix matrix1, Matrix matrix2, char firtsChar, char senondChar)
        {
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 5; j++)
                {
                    if (matrix1.GetMas()[i, j] == firtsChar)
                    {
                        i1 = i;
                        j1 = j;
                    }

                    if (matrix2.GetMas()[i, j] == senondChar)
                    {
                        i2 = i;
                        j2 = j;
                    }
                }
        }

        public static void GetIndexForEnc(ref int i1, ref int j1, ref int i2, ref int j2, ref int modI, ref int modJ, Matrix matrix1, Matrix matrix2, Matrix modMatrix, char firtsChar, char senondChar, char thirdChar)
        {
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 5; j++)
                {
                    if (matrix1.GetMas()[i, j] == firtsChar)
                    {
                        i1 = i;
                        j1 = j;
                    }

                    if (matrix2.GetMas()[i, j] == senondChar)
                    {
                        i2 = i;
                        j2 = j;
                    }

                    if (modMatrix.GetMas()[i, j] == thirdChar)
                    {
                        modI = i;
                        modJ = j;
                    }
                }
        }

        public static void GetIndexForDec(ref int i1, ref int j1, ref int i2, ref int j2, Matrix matrix1, Matrix matrix2, char firtsChar, char senondChar)
        {
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 5; j++)
                {
                    if (matrix2.GetMas()[i, j] == firtsChar)
                    {
                        i1 = i;
                        j1 = j;
                    }

                    if (matrix1.GetMas()[i, j] == senondChar)
                    {
                        i2 = i;
                        j2 = j;
                    }
                }
        }

        public static void GetIndexForDec(ref int i1, ref int j1, ref int i2, ref int j2, ref int modI, ref int modJ, Matrix matrix1, Matrix matrix2, Matrix modMatrix, char firtsChar, char senondChar, char thirdChar, bool b)
        {
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 5; j++)
                {
                    if (modMatrix.GetMas()[i, j] == firtsChar)
                    {
                        i1 = i;
                        j1 = j;
                    }

                    if (modMatrix.GetMas()[i, j] == senondChar)
                    {
                        i2 = i;
                        j2 = j;
                    }

                    if ( b == true && matrix1.GetMas()[i, j] == thirdChar)
                    {
                        modI = i;
                        modJ = j;
                    }

                    if (b == false && matrix2.GetMas()[i, j] == thirdChar)
                    {
                        modI = i;
                        modJ = j;
                    }
                }
        }

        public static void GetNewKeyWord(ref string keyword)
        {
            for (int i = 0; i < keyword.Length; i++)
                for (int j = 1 + i; j < keyword.Length; j++)
                    if (keyword[i] == keyword[j])
                    {
                        keyword = keyword.Remove(j, 1);
                    }
        }

        public static void ModStr(char c, Matrix matrix, ref int modI, ref int modJ)
        {
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 5; j++)
                    if (matrix.GetMas()[i, j] == c)
                    {
                        modI = i;
                        modJ = j;
                    }
        }
    }
}
