﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace KBLab2
{
    class KeyGeneration
    {
        public static BigInteger GeneratePrimeNumber()
        {
            Random rand = new Random();
            BigInteger N = (BigInteger)1e29;
            byte[] number = N.ToByteArray();
            BigInteger R = 0;

            do
            {
                rand.NextBytes(number);
                R = new BigInteger(number);
                R = BigInteger.Abs(R);
            } while (R >= N || SoloveiShtrassen(R) == false);

             return R;
        }

        public static BigInteger GeneratePublicKey(BigInteger d)
        {
            BigInteger openKey = GeneratePrimeNumber();
            while (BigInteger.GreatestCommonDivisor(d, openKey) != 1)
                openKey--;
            return openKey;
        }

        //Обобщенный алгоритм Евклида
        public static BigInteger GeneratePrivateKey(BigInteger s, BigInteger d)
        {
            BigInteger[] u = { d, 1, 0 }, v = { s, 0, 1 };
            while (v[0] != 0)
            {
                BigInteger q = u[0] / v[0];
                BigInteger[] t = { u[0] % v[0], u[1] - q * v[1], u[2] - q * v[2] };
                u = v;
                v = t;
            }
            if (u[2] < 0)
                u[2] += d;
            return u[2];
        }

        private static BigInteger GenerateRandom(BigInteger start, BigInteger end, Random rand)
        {
            BigInteger bi;

            while (true)
            {
                byte[] randomBytesBuf = new byte[rand.Next(1, 17)];
                rand.NextBytes(randomBytesBuf);
                bi = new BigInteger(randomBytesBuf);

                if (bi > start && bi < end)
                    break;
            }
            return bi;
        }

        private static bool SoloveiShtrassen(BigInteger n)
        {
            int count = 0;
            int t = 1000;
            Random rnd = new Random((int)(DateTime.Now.Ticks));
            for (int i = 0; i < t; i++)
            {
                BigInteger a = GenerateRandom(2, n - 2, rnd);
                if (BigInteger.GreatestCommonDivisor(a, n) != 1)
                    break;

                BigInteger Jc = Jakobi(a, n);
                BigInteger S = BigInteger.ModPow(a, (n - 1) / 2, n);

                S = (S + 1 == n) ? S - n : S;
                if (Jc != S)
                    break;
                else
                    count++;
            }
            if (count == t)
                return true;
            return false;
        }
        //Вспомогательный метод для Соловея-Штрассена
        private static int Jakobi(BigInteger a, BigInteger b)
        {
            if (BigInteger.GreatestCommonDivisor(a, b) != 1)
                return 0;

            int r = 1;
            BigInteger c;

            if (a < 0)
            {
                a = -a;
                if (b % 4 == 3)
                    r = -r;
            }

            while (a != 0)
            {
                int i = 0;
                while (a % 2 == 0)
                {
                    i++;
                    a /= 2;
                }
                if (i % 2 != 0)
                    if (b % 8 == 3 || b % 8 == 5)
                        r = -r;

                if (a % 4 == b % 4 && a % 4 == 3)
                    r = -r;
                c = a;
                a = b % c;
                b = c;
            }
            return r;
        }
    }
}
