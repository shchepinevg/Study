﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using System.IO;
using System.Diagnostics;

namespace KBLab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            BigInteger s = 0, N = 0;
            BigInteger.TryParse(sBox.Text, out s);
            BigInteger.TryParse(nBox.Text, out N);

            if (sBox.Text.Length == 0 || nBox.Text.Length == 0)
            {
                MessageBox.Show("Введите ключи s и N!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (textBox.Text.Length == 0)
            {
                MessageBox.Show("Введите текст!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string crypt = "";
            BigInteger[] blocks = Conversion.toBlocks(textBox.Text, 58);
            for (int i = 0; i < blocks.Length; i++)
                crypt += BigInteger.ModPow(blocks[i], s, N).ToString() + ' ';
            resultBox.Text = crypt.Substring(0, crypt.Length - 1);
        }

        private void btnDecrypt_Click(object sender, EventArgs ee)
        {
            BigInteger N = 0, e = 0;
            BigInteger.TryParse(nBox.Text, out N);
            BigInteger.TryParse(eBox.Text, out e);

            if (eBox.Text.Length == 0 || nBox.Text.Length == 0)
            {
                MessageBox.Show("Введите ключи e и N!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (textBox.Text.Length == 0)
            {
                MessageBox.Show("Введите текст!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] code = textBox.Text.Split(' ');
            BigInteger[] blocks = new BigInteger[code.Length];
            string text;
            BigInteger symbolCode;

            for (int i = 0; i < code.Length; i++)
            {
                BigInteger.TryParse(code[i], out symbolCode);
                blocks[i] = BigInteger.ModPow(symbolCode, e, N);
            }

            text = Conversion.toText(blocks);
            resultBox.Text = text;
        }

        private void btnCreateKeys_Click(object sender, EventArgs ee)
        {
            BigInteger p = 0, q = 0, N = 0;

            Stopwatch timer = new Stopwatch();
            timer.Start();
            do
            {
                p = KeyGeneration.GeneratePrimeNumber();
                q = KeyGeneration.GeneratePrimeNumber();
                N = p * q;
            } while (N.ToString().Length != 58);

            BigInteger d = (p - 1) * (q - 1);
            BigInteger s = KeyGeneration.GeneratePublicKey(d);
            BigInteger e = KeyGeneration.GeneratePrivateKey(s, d);
            timer.Stop();
            textBox1.Text = timer.Elapsed.ToString();

            sBox.Text = s.ToString();
            eBox.Text = e.ToString();
            nBox.Text = N.ToString();
        }

        private void btnUseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            try
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    StreamReader sr = new StreamReader(ofd.FileName);
                    textBox.Text = sr.ReadToEnd();
                    sr.Close();
                }
            }
            catch
            {
                MessageBox.Show("Неудалось открыть файл", "Ошибка");
            }
        }

        private void copyUp_Click(object sender, EventArgs e)
        {
            textBox.Text = resultBox.Text;
            resultBox.Text = "";
        }
    }
}
