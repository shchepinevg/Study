﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace KBLab2
{
    class Conversion
    {
        public static BigInteger[] toBlocks(string text, int n)
        {
            string code = "";
            for (int i = 0; i < text.Length; i++)
                code += toFive(text[i]);
            int[] k = averageSplit(code.Length, n - 2);
            BigInteger[] blocks = new BigInteger[k.Length];
            int tmp = 0;
            for (int i = 0; i < k.Length; i++)
            {
                blocks[i] = BigInteger.Parse("1" + code.Substring(tmp, k[i]));
                tmp += k[i];
            }
            return blocks;
        }

        private static string toFive(char c)
        {
            string nulls = "";
            string code = ((int)c).ToString();
            for (int i = 0; i < 5 - code.Length; i++)
                nulls += "0";
            return nulls + code;
        }

        private static int[] averageSplit(int l, int n)
        {
            int size = (l / n) + 1;
            int[] k = new int[size];
            for (int i = 0; i < size; i++)
                k[i] = l / size;
            int b = l - ((l / size) * size);
            for (int i = 0; i < b; i++)
                k[i]++;
            return k;
        }

        public static string toText(BigInteger[] blocks)
        {
            string code = "";
            for (int i = 0; i < blocks.Length; i++)
                code += blocks[i].ToString().Substring(1);
            char[] text = new char[code.Length / 5];
            for (int i = 0; i < code.Length / 5; i++)
                text[i] = (char)Convert.ToInt32(code.Substring(5 * i, 5));
            return new string(text);
        }
    }
}
