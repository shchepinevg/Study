﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class InterfaceObject
    {
        public int Length { get; set; }
        public int Height { get; set; }
        public string Name { get; set; }

        public InterfaceObject(int lenght, int height, string name)
        {
            Length = lenght;
            Height = height;
            Name = name;
        }

        public void ShowInfo()
        {
        }
    }
}
