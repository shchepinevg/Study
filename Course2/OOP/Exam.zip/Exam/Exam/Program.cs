﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            Button button = new Button(200, 300, "qwe", "qwe");

            Edit edit = new Edit(300, 400, "asd", "asd");

            Panel panel = new Panel();
            panel.objects = new List<InterfaceObject>();
            panel.objects.Add(button);
            panel.objects.Add(edit);
            panel.ShowMyObjects();
            Console.ReadKey();
        }
    }
}
