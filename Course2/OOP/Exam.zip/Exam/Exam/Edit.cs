﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Edit : InterfaceObject
    {
        public string Text { get; set; }

        public Edit(int length, int heigth, string name, string text) : base(length, heigth, name)
        {
            this.Text = text;
        }
    }
}
