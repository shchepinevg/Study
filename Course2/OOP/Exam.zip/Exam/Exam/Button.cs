﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Button : InterfaceObject
    {
        public string Caption { get; set; }

        public Button(int lenght, int height, string name, string caption) : base(lenght, height, caption)
        {
            this.Caption = caption;
        }

    }
}
