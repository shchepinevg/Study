﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Panel
    {
        public List<InterfaceObject> objects { get; set; }

        public void ShowMyObjects()
        {
            foreach(InterfaceObject intf in objects)
            {
                if (intf is Button)
                {
                    Button b = intf as Button;
                    Console.WriteLine(b.Height);
                    Console.WriteLine(b.Length);
                    Console.WriteLine(b.Name);
                    Console.WriteLine(b.Caption);
                }

                if (intf is Edit)
                {
                    Edit e = intf as Edit;
                    Console.WriteLine(e.Height);
                    Console.WriteLine(e.Length);
                    Console.WriteLine(e.Name);
                    Console.WriteLine(e.Text);
                }
            }
        }
    }
}
