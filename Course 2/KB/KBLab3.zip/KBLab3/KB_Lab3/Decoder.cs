﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace KB_Lab3
{
    class Decoder
    {
        public static string FindKeyByFA(string text, int keyLength)
        {
            int index = 0;
            int[] lettersCount = new int[32];
            List<int> keyEquivalent = new List<int>();
            string[] texts = new string[keyLength];

            texts[0] = Methods.SplitText(text, keyLength);
            for (int i = 1; i < texts.Length; i++)
            {
                text = text.Substring(1, text.Length - i);
                texts[i] = Methods.SplitText(text, keyLength);
            }

            for (int i = 0; i < keyLength; i++)
            {
                for (int j = 0; j < lettersCount.Length; j++)
                    lettersCount[j] = 0;

                for (int j = 0; j < texts[i].Length; j++)
                {
                    lettersCount[(int)texts[i][j] - 1040]++;
                }

                int k = lettersCount[0];
                for (int j = 0; j < lettersCount.Length - 1; j++)
                {
                    if (k < lettersCount[j + 1])
                    {
                        k = lettersCount[j + 1];
                        index = j + 1;
                    }
                }
                keyEquivalent.Add(index);
            }

            for (int i = 0; i < keyEquivalent.Count; i++)
            {
                keyEquivalent[i] = (char)(1040 + ((Convert.ToInt32(keyEquivalent[i]) - 14 + 32) % 32));
            }

            char[] c = new char[keyEquivalent.Count];
            for (int j = 0; j < c.Length; j++)
                c[j] = (char)(keyEquivalent[j]);

            return new string(c);
        }

        public static List<string> FindKeysByDictionary(string text, int keyLength, string keyFA)
        {
            string path = "C:\\Users\\User\\Documents\\Visual Studio 2015\\Projects\\c#\\KB_Lab3\\KB_Lab3\\files\\file" + keyLength.ToString() + ".txt";

            FileStream file = new FileStream(path, FileMode.Open);
            StreamReader reader = new StreamReader(file, Encoding.Default);
            List<int> countLetters = new List<int>();
            List<int> index = new List<int>();
            List<string> dictionary = new List<string>();
            int k = 0;
            string str = "";

            while ((str = reader.ReadLine()) != null)
            {
                dictionary.Add(str);
                k = 0;
                for (int i = 0; i < keyLength; i++)
                {
                    if (keyFA[i] == str[i])
                        k++;
                }
                countLetters.Add(k);
            }
            reader.Close();

            int max = countLetters[0];
            for (int i = 1; i < countLetters.Count; i++)
            {
                if (max < countLetters[i])
                    max = countLetters[i];
            }

            for (int i = 0; i < countLetters.Count; i++)
            {
                if (countLetters[i] == max)
                    index.Add(i);
            }

            List<string> keys = new List<string>();

            for (int i = 0; i < index.Count; i++)
            {
                keys.Add(dictionary[index[i]]);
            }
            return keys;
        }

        public static string DecryptionText(string cipher, string key)
        {
            string text = string.Empty;
            int j = 0;
            for (int i = 0; i < cipher.Length; i++)
            {
                if (cipher[i] > 1039 && cipher[i] < 1072)
                {
                    text += (char)(1040 + ((Convert.ToInt32(cipher[i]) - Convert.ToInt32(key[j]) + 32) % 32));
                    j++;
                }
                else
                    text += cipher[i];
                j %= key.Length;
            }
            return text;
        }
    }
}
