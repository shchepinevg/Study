﻿namespace KB_Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ciphertextBox = new System.Windows.Forms.TextBox();
            this.keyBox = new System.Windows.Forms.TextBox();
            this.btnFindKeys = new System.Windows.Forms.Button();
            this.btnDecryption = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.keyscomboBox = new System.Windows.Forms.ComboBox();
            this.decipheredtextBox = new System.Windows.Forms.TextBox();
            this.checkBox = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ciphertextBox
            // 
            this.ciphertextBox.Location = new System.Drawing.Point(12, 25);
            this.ciphertextBox.Multiline = true;
            this.ciphertextBox.Name = "ciphertextBox";
            this.ciphertextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ciphertextBox.Size = new System.Drawing.Size(344, 134);
            this.ciphertextBox.TabIndex = 0;
            // 
            // keyBox
            // 
            this.keyBox.Location = new System.Drawing.Point(362, 97);
            this.keyBox.Name = "keyBox";
            this.keyBox.Size = new System.Drawing.Size(140, 20);
            this.keyBox.TabIndex = 2;
            // 
            // btnFindKeys
            // 
            this.btnFindKeys.Location = new System.Drawing.Point(362, 25);
            this.btnFindKeys.Name = "btnFindKeys";
            this.btnFindKeys.Size = new System.Drawing.Size(140, 22);
            this.btnFindKeys.TabIndex = 4;
            this.btnFindKeys.Text = "1) Найти ключи";
            this.btnFindKeys.UseVisualStyleBackColor = true;
            this.btnFindKeys.Click += new System.EventHandler(this.btnFindKeys_Click);
            // 
            // btnDecryption
            // 
            this.btnDecryption.Location = new System.Drawing.Point(12, 165);
            this.btnDecryption.Name = "btnDecryption";
            this.btnDecryption.Size = new System.Drawing.Size(344, 26);
            this.btnDecryption.TabIndex = 5;
            this.btnDecryption.Text = "4) Расшифровать";
            this.btnDecryption.UseVisualStyleBackColor = true;
            this.btnDecryption.Click += new System.EventHandler(this.btnDecryption_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Шифротекст:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Расшифрованный текст:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(359, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "2) Ключ найденный ч/а:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(359, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "3) Ключ из словаря:";
            // 
            // keyscomboBox
            // 
            this.keyscomboBox.FormattingEnabled = true;
            this.keyscomboBox.Location = new System.Drawing.Point(362, 167);
            this.keyscomboBox.Name = "keyscomboBox";
            this.keyscomboBox.Size = new System.Drawing.Size(140, 21);
            this.keyscomboBox.TabIndex = 10;
            // 
            // decipheredtextBox
            // 
            this.decipheredtextBox.Location = new System.Drawing.Point(12, 209);
            this.decipheredtextBox.Multiline = true;
            this.decipheredtextBox.Name = "decipheredtextBox";
            this.decipheredtextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.decipheredtextBox.Size = new System.Drawing.Size(344, 134);
            this.decipheredtextBox.TabIndex = 11;
            // 
            // checkBox
            // 
            this.checkBox.AutoSize = true;
            this.checkBox.Location = new System.Drawing.Point(362, 8);
            this.checkBox.Name = "checkBox";
            this.checkBox.Size = new System.Drawing.Size(15, 14);
            this.checkBox.TabIndex = 12;
            this.checkBox.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(378, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Перебором";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 353);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.checkBox);
            this.Controls.Add(this.decipheredtextBox);
            this.Controls.Add(this.keyscomboBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDecryption);
            this.Controls.Add(this.btnFindKeys);
            this.Controls.Add(this.keyBox);
            this.Controls.Add(this.ciphertextBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ciphertextBox;
        private System.Windows.Forms.TextBox keyBox;
        private System.Windows.Forms.Button btnFindKeys;
        private System.Windows.Forms.Button btnDecryption;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox keyscomboBox;
        private System.Windows.Forms.TextBox decipheredtextBox;
        private System.Windows.Forms.CheckBox checkBox;
        private System.Windows.Forms.Label label5;
    }
}

