﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KB_Lab3
{
    class KeyLength
    {
        public static int FindByTestKasiski(string text)
        {
            List<int> repeatCount = new List<int>();
            int digramLength = 3;
            for (int i = 0; i < text.Length - digramLength + 1; i++)
            {
                string temp = text.Substring(i, digramLength);
                for (int j = i + 1; j < text.Length - digramLength + 1; j++)
                {
                    string temp2 = text.Substring(j, digramLength);
                    if (temp.Equals(temp2))
                    {
                        repeatCount.Add(j - i);
                    }
                }
            }

            int index = 0;
            int[] nods = new int[5000];
            for (int i = 0; i < nods.Length; i++)
                nods[i] = 0;

            for (int i = 0; i < repeatCount.Count; ++i)
                for (int j = i + 1; j < repeatCount.Count; ++j)
                    if (Methods.gcd(repeatCount[i], repeatCount[j]) != 1)
                    {
                        nods[Methods.gcd(repeatCount[i], repeatCount[j])]++;
                    }

            int max = nods[0];
            for (int i = 0; i < nods.Length - 1; i++)
            {
                if (max < nods[i + 1])
                {
                    max = nods[i + 1];
                    index = i + 1;
                }
            }

            if (FindByConformityIndex(text, index))
                return index;

           return 1;
        }
        
        private static bool FindByConformityIndex(string text, int period)
        {
            int[] lettersCount = new int[32];
            for (int i = 0; i < lettersCount.Length; i++)
                lettersCount[i] = 0;

            double ci = 0;
            double a = 0;
            for (int i = 0; i < text.Length; i++)
            {
                lettersCount[(int)text[i] - 1040]++;
            }

            for (int i = 0; i < lettersCount.Length; i++)
            {
                a += lettersCount[i] * (lettersCount[i] - 1);
            }

            ci = a / (text.Length * (text.Length - 1));

            if (ci >= 0.055 && ci <= 0.0615 && period == 1)
                return true;
            else if (ci >= 0.0395 && ci <= 0.055 && period == 2)
                return true;
            else if (ci >= 0.0355 && ci <= 0.044 && period == 3)
                return true;
            else if (ci >= 0.035 && ci <= 0.0405 && period == 4)
                return true;
            else if (ci >= 0.0335 && ci <= 0.039 && period == 5)
                return true;
            else if (ci >= 0.0325 && ci <= 0.0385 && period == 6)
                return true;
            else if (ci >= 0.0315 && ci <= 0.0365 && period == 7)
                return true;
            else
                return false;
        }
    }
}
