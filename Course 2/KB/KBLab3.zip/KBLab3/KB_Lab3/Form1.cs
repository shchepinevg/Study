﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KB_Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static int bruteForce = 2;

        private void btnFindKeys_Click(object sender, EventArgs e)
        {
            if (ciphertextBox.Text.Length == 0)
            {
                MessageBox.Show("Введите шифротекст", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            keyscomboBox.Items.Clear();
            List<string> keys = new List<string>();
            string text = Methods.Trim(ciphertextBox.Text);
            int keyLength = 0;

            if (checkBox.Checked == true)
            {
                keyLength = bruteForce;
                bruteForce++;
            }
            else
            {
                bruteForce = 2;
                keyLength = KeyLength.FindByTestKasiski(text);
                if (keyLength == 1)
                {
                    checkBox.Checked = true;
                    keyLength++;
                    bruteForce++;
                }
            }

            keyBox.Text = Decoder.FindKeyByFA(text, keyLength);
            keys = Decoder.FindKeysByDictionary(text, keyLength, keyBox.Text);

            for (int i = 0; i < keys.Count; i++)
            {
                keyscomboBox.Items.Add(keys[i]);
            }
        }

        private void btnDecryption_Click(object sender, EventArgs e)
        {
            if (keyscomboBox.Text.Length == 0 || ciphertextBox.Text.Length == 0)
            {
                MessageBox.Show("Выберите ключ из словаря", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decipheredtextBox.Text = Decoder.DecryptionText(ciphertextBox.Text, keyscomboBox.Text);
        }
    }
}
