﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KB_Lab3
{
    class Methods
    {
        public static string Trim(string text)
        {
            string str = "";
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] >= 'А' && text[i] <= 'Я')
                {
                    str += text[i];
                }
            }
            return str;
        }

        public static string SplitText(string text, int k)
        {
            string str = "";
            for (int i = 0; i < text.Length; i = i + k)
            {
                str += text[i];
            }

            return str;
        }

        public static int gcd(int a, int b)
        {
            if (b == 0)
            {
                return a;
            }
            else
            {
                return gcd(b, a % b);
            }
        }
    }
}
