﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab1
{
    public class Train
    {
        private List<Wagon> listWagons;

        public int Number { get; set; }

        public string Company { get; set; }

        public string From { get; set; }

        public string To { get; set; }

        public Train()
        {
            listWagons = new List<Wagon>();
        }

        public void AddWagon(Wagon wagon)
        {
            listWagons.Add(wagon);
        }

        public Wagon GetWagon(int i)
        {
            return listWagons[i];
        }

        public int GetWagonCount()
        {
            return listWagons.Count;
        }
    }
}
