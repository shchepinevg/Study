﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab1
{
    public class Wagon
    {
        private List<Place> listPlace;

        public int Number { get; set; }

        public Wagon()
        {
            listPlace = new List<Place>();
        }

        public void AddPlace(Place place)
        {
            listPlace.Add(place);
        }

        public Place GetPlace(int i)
        {
            return listPlace[i];
        }

        public int GetPlaceCount()
        {
            return listPlace.Count;
        }
    }
}
