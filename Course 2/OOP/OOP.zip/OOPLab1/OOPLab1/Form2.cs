﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLab1
{
    public partial class Form2 : Form
    {
        private List<Train> listTrain;

        private int proverka;

        public int Proverka
        {
            get
            {
                return proverka;
            }
        }

        public Form2(List<Train> listTrain)
        {
            InitializeComponent();
            this.listTrain = listTrain;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void addNewTrain(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!");
                return;
            }

            foreach (Train tr in listTrain)
                if (tr.Number == numericUpDown1.Value)
                {
                    MessageBox.Show("Такой поезд уже существует");
                    return;
                }

            Train train = new Train();

            train.Number = Convert.ToInt32(numericUpDown1.Value);
            train.Company = textBox1.Text;
            train.From = textBox2.Text;
            train.To = textBox3.Text;
            listTrain.Add(train);
            MessageBox.Show("Поезд №" + train.Number + " добавлен");
            proverka = 1;

            Close();
        }
    }
}
