﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLab1
{
    public partial class Form4 : Form
    {
        private List<Train> listTrain;

        private int proverka;

        public int Proverka
        {
            get
            {
                return proverka;
            }
        }

        public Form4(List<Train> listTrain)
        {
            InitializeComponent();
            this.listTrain = listTrain;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            foreach (Train tr in listTrain)
                trainComboBox.Items.Add("Поезд №" + tr.Number);
            trainComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            wagonComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void chooseTrain(object sender, EventArgs e)
        {
            wagonComboBox.Items.Clear();

            if (trainComboBox.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!");
                return;
            }

            label3.Visible = true;
            wagonComboBox.Visible = true;

            List<Wagon> listWagon = new List<Wagon>();

            for (int i = 0; i < listTrain[trainComboBox.SelectedIndex].GetWagonCount(); i++)
                listWagon.Add(listTrain[trainComboBox.SelectedIndex].GetWagon(i));

            foreach (Wagon wg in listWagon)
                wagonComboBox.Items.Add("Вагон №" + wg.Number);
        }

        private void addNewPlace(object sender, EventArgs e)
        {
            if (trainComboBox.Text == "" || wagonComboBox.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!");
                return;
            }

            Wagon wg = new Wagon();
            wg = listTrain[trainComboBox.SelectedIndex].GetWagon(wagonComboBox.SelectedIndex);
            for (int i = 0; i < wg.GetPlaceCount(); i++)
                if (wg.GetPlace(i).Number == numericUpDown1.Value)
                {
                    MessageBox.Show("Такое место уже существует");
                    return;
                }

            Place place = new Place();

            place.Number = Convert.ToInt32(numericUpDown1.Value);
            listTrain[trainComboBox.SelectedIndex].GetWagon(wagonComboBox.SelectedIndex).AddPlace(place);

            MessageBox.Show("Место №" + place.Number + " добавлено");
            proverka = 1;

            Close();
        }
    }
}
