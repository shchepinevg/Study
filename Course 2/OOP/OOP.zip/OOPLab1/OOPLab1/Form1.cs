﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLab1
{
    public partial class Form1 : Form
    {
        private List<Train> listTrain;

        public Form1()
        {
            InitializeComponent();
            listTrain = new List<Train>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }


        private void addTrain(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(listTrain);
            form2.ShowDialog();
            UpdateTree();
            switch (form2.Proverka)
            {
                case 1:
                    UpdateTree();
                    break;
                default:
                    return;
            }
        }

        private void addWagon(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(listTrain);
            form3.ShowDialog();

            switch (form3.Proverka)
            {
                case 1:
                    UpdateTree();
                    break;
                default:
                    return;
            }
        }

        private void addPlace(object sender, EventArgs e)
        {
            Form4 form4 = new Form4(listTrain);
            form4.ShowDialog();

            switch (form4.Proverka)
            {
                case 1:
                    UpdateTree();
                    break;
                default:
                    return;
            }
        }

        private void UpdateTree()
        {
            treeView1.Nodes.Clear();
            Train train;

            for (int i = 0; i < listTrain.Count; i++)
            {
                train = listTrain[i];
                TreeNode tr = new TreeNode("Поезд №" + train.Number);
                tr.Nodes.Add("Компания: " + train.Company);
                tr.Nodes.Add("Откуда: " + train.From);
                tr.Nodes.Add("Куда: " + train.To);
                TreeNode wagon = new TreeNode("Вагоны");
                tr.Nodes.Add(wagon);

                for (int j = 0; j < train.GetWagonCount(); j++)
                {
                    TreeNode wg = new TreeNode("Вагон №" + train.GetWagon(j).Number);

                    for (int k = 0; k < train.GetWagon(j).GetPlaceCount(); k++)
                    {
                        TreeNode pl = new TreeNode("Место №" + train.GetWagon(j).GetPlace(k).Number);
                        wg.Nodes.Add(pl);
                    }

                    wagon.Nodes.Add(wg);
                }
                treeView1.Nodes.Add(tr);
            }
        }

        private void Exit(object sender, EventArgs e)
        {
            Close();
        }
    }
}
