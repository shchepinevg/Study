﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLab1
{
    public partial class Form3 : Form
    {
        private List<Train> listTrain;

        private int proverka;

        public int Proverka
        {
            get
            {
                return proverka;
            }
        }

        public Form3(List<Train> listTrain)
        {
            InitializeComponent();
            this.listTrain = listTrain;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            foreach (Train tr in listTrain)
                comboBox1.Items.Add("Поезд №" + tr.Number);
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void addNewWagon(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!");
                return;
            }

            for (int i = 0; i < listTrain[comboBox1.SelectedIndex].GetWagonCount(); i++)
                if (listTrain[comboBox1.SelectedIndex].GetWagon(i).Number == numericUpDown1.Value)
                {
                    MessageBox.Show("Такой вагон уже есть");
                    return;
                }

            Wagon wagon = new Wagon();

            wagon.Number = Convert.ToInt32(numericUpDown1.Value);
            listTrain[comboBox1.SelectedIndex].AddWagon(wagon);
            MessageBox.Show("Вагон №" + wagon.Number + " добавлен");
            proverka = 1;

            Close();
        }
    }
}
