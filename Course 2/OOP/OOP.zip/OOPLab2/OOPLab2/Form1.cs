﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLab2
{
    public partial class FormShip : Form
    {
        public FormShip()
        {
            InitializeComponent();
        }

        private void FormShip_Load(object sender, EventArgs e)
        {
            ChooseShip.Items.Add("Пароход");
            ChooseShip.Items.Add("Парусник");
            ChooseShip.Items.Add("Корвет");
        }

        private void AddSteamer_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2(1);
            form.ShowDialog();
        }

        private void AddSailboat_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2(2);
            form.ShowDialog();
        }

        private void AddCorvette_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2(3);
            form.ShowDialog();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void GetSteamers(List<Steamer> listSteamer)
        {
            for (int i = 0; i < Ship.GetShipCount(); i++)
                if (Ship.GetShip(i) is Steamer)
                    listSteamer.Add(Ship.GetShip(i) as Steamer);
        }

        private void GetSailboats(List<Sailboat> listSailboat)
        {
            for (int i = 0; i < Ship.GetShipCount(); i++)
                if (Ship.GetShip(i) is Sailboat)
                    listSailboat.Add(Ship.GetShip(i) as Sailboat);
        }

        private void GetCorvettes(List<Corvette> listCorvette)
        {
            for (int i = 0; i < Ship.GetShipCount(); i++)
                if (Ship.GetShip(i) is Corvette)
                    listCorvette.Add(Ship.GetShip(i) as Corvette);
        }

        private void ChooseShip_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ChooseShip.SelectedIndex == 0)
            {
                List<Steamer> listSteamer = new List<Steamer>();
                GetSteamers(listSteamer);
                Information.DataSource = listSteamer;
                Information.Refresh();
            }

            if (ChooseShip.SelectedIndex == 1)
            {
                List<Sailboat> listSailboat = new List<Sailboat>();
                GetSailboats(listSailboat);
                Information.DataSource = listSailboat;
                Information.Refresh();
            }

            if (ChooseShip.SelectedIndex == 2)
            {
                List<Corvette> listCorvette = new List<Corvette>();
                GetCorvettes(listCorvette);
                Information.DataSource = listCorvette;
                Information.Refresh();
            }
        }
    }
}
