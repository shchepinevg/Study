﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab2
{
    class Ship
    {
        public string Name { get; set; }
        public int Length { get; set; }
        public int Width { get; set; }
        public int Speed { get; set; }
        public int Crew { get; set; }

        private static List<Ship> listShip = new List<Ship>();

        public Ship()
        {
            AddShip(this);
        }

        private static void AddShip(Ship ship)
        {
            listShip.Add(ship);
        }

        public static Ship GetShip(int i)
        {
            return listShip[i];
        }

        public static int GetShipCount()
        {
            return listShip.Count;
        }

        public virtual string GetInfo()
        {
            return "Названи: " + Name + "\n" +
                    "Длина: " + Length + "\n" +
                    "Ширина: " + Width + "\n" +
                    "Скорость: " + Speed + "\n" +
                    "Экипаж: " + Crew + "\n"; 
        }
    }
}
