﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLab2
{
    public partial class Form2 : Form
    {
        private int check;

        public Form2(int check)
        {
            InitializeComponent();
            this.check = check;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            switch(check)
            {
                case 1:
                    this.Text = "Steamer";
                    newLabel1.Text = "КПД:";
                    newLabel2.Text = "Частота:\n вращения\n вала";
                    NewComboBox.Items.Clear();
                    NewComboBox.Items.Add("До 50 об/мин (тихоходный)");
                    NewComboBox.Items.Add("Более 50 об/мин (быстроходный)");
                    break;
                case 2:
                    this.Text = "Sailboat";
                    newLabel1.Text = "Кол-во парусов:";
                    newLabel2.Text = "Назначение:";
                    NewComboBox.Items.Clear();
                    NewComboBox.Items.Add("Транспортный");
                    NewComboBox.Items.Add("Промысловый");
                    NewComboBox.Items.Add("Экспедиционный");
                    NewComboBox.Items.Add("Учебный");
                    break;
                case 3:
                    this.Text = "Corvette";
                    newLabel1.Text = "Боеприпасы:";
                    newLabel2.Text = "Вооружение:";
                    NewComboBox.Items.Clear();
                    NewComboBox.Items.Add("Артиллерийские установки");
                    NewComboBox.Items.Add("Зенитные автоматы");
                    NewComboBox.Items.Add("Бомбомёты");
                    NewComboBox.Items.Add("Глубинные бомбы");
                    break;
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(NameTextBox.Text) || String.IsNullOrWhiteSpace(LengthTextBox.Text) ||
                String.IsNullOrWhiteSpace(WidthTextBox.Text) || String.IsNullOrWhiteSpace(SpeedTextBox.Text) || 
                String.IsNullOrWhiteSpace(CrewTextBox.Text) || String.IsNullOrWhiteSpace(NewTextBox.Text) || 
                String.IsNullOrWhiteSpace(NewComboBox.Text))
            {
                MessageBox.Show("Введены не все поля");
                return;
            }   

            try
            {
                int.Parse(LengthTextBox.Text);
                int.Parse(WidthTextBox.Text);
                int.Parse(SpeedTextBox.Text);
                int.Parse(CrewTextBox.Text);
                int.Parse(NewTextBox.Text);
            }
            catch(Exception)
            {
                MessageBox.Show("Введено некорректное(ые) значение(я)");
                return;
            }

            if (int.Parse(LengthTextBox.Text) <= 0 || int.Parse(WidthTextBox.Text) <= 0 ||
               int.Parse(SpeedTextBox.Text) <= 0 || int.Parse(CrewTextBox.Text) <= 0 || int.Parse(NewTextBox.Text) <= 0)
            {
                MessageBox.Show("Введено некорректное(ые) значение(я)");
                return;
            }

            switch (check)
            {
                case 1:
                    {   
                        for (int i = 0; i < Ship.GetShipCount(); i++)
                            if (Ship.GetShip(i) is Steamer && Ship.GetShip(i).Name == NameTextBox.Text)
                            {                               
                                MessageBox.Show("Такой пароход уже существует");
                                return;
                            }

                        Steamer steamer = new Steamer();
                        steamer.Name = NameTextBox.Text;
                        steamer.Length = int.Parse(LengthTextBox.Text);
                        steamer.Width = int.Parse(WidthTextBox.Text);
                        steamer.Speed = int.Parse(SpeedTextBox.Text);
                        steamer.Crew = int.Parse(CrewTextBox.Text);
                        steamer.Efficiency = int.Parse(NewTextBox.Text);
                        steamer.ShaftSpeed = NewComboBox.Text;

                        MessageBox.Show("Пароход добавлен!\n\n" + steamer.GetInfo());
                    }
                    break;
                case 2:
                    {
                        for (int i = 0; i < Ship.GetShipCount(); i++)
                            if (Ship.GetShip(i) is Sailboat && Ship.GetShip(i).Name == NameTextBox.Text)
                            {
                                MessageBox.Show("Такой парусник уже существует");
                                return;
                            }

                        Sailboat sailboat = new Sailboat();
                        sailboat.Name = NameTextBox.Text;
                        sailboat.Length = int.Parse(LengthTextBox.Text);
                        sailboat.Width = int.Parse(WidthTextBox.Text);
                        sailboat.Speed = int.Parse(SpeedTextBox.Text);
                        sailboat.Crew = int.Parse(CrewTextBox.Text);
                        sailboat.NumberofSails = int.Parse(NewTextBox.Text);
                        sailboat.Appointment = NewComboBox.Text;

                        MessageBox.Show("Парусник добавлен!\n\n" + sailboat.GetInfo());
                    }
                    break;
                case 3:
                    {
                        for (int i = 0; i < Ship.GetShipCount(); i++)
                            if (Ship.GetShip(i) is Corvette && Ship.GetShip(i).Name == NameTextBox.Text)
                            {
                                MessageBox.Show("Такой корвет уже существует");
                                return;
                            }

                        Corvette corvette = new Corvette();
                        corvette.Name = NameTextBox.Text;
                        corvette.Length = int.Parse(LengthTextBox.Text);
                        corvette.Width = int.Parse(WidthTextBox.Text);
                        corvette.Speed = int.Parse(SpeedTextBox.Text);
                        corvette.Crew = int.Parse(CrewTextBox.Text);
                        corvette.Ammunition = int.Parse(NewTextBox.Text);
                        corvette.Armament = NewComboBox.Text;

                        MessageBox.Show("Корвет добавлен!\n\n" + corvette.GetInfo());
                    }
                    break;
            }
            
            Close();
        }
    }
}
