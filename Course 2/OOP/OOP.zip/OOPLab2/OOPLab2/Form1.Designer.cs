﻿namespace OOPLab2
{
    partial class FormShip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.AddCorvette = new System.Windows.Forms.Button();
            this.AddSailboat = new System.Windows.Forms.Button();
            this.AddSteamer = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Information = new System.Windows.Forms.DataGridView();
            this.ChooseShip = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Information)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.ItemSize = new System.Drawing.Size(275, 25);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(553, 348);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.Exit);
            this.tabPage1.Controls.Add(this.AddCorvette);
            this.tabPage1.Controls.Add(this.AddSailboat);
            this.tabPage1.Controls.Add(this.AddSteamer);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(545, 315);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Добавить";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "Добавить:";
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(229, 272);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(93, 26);
            this.Exit.TabIndex = 3;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // AddCorvette
            // 
            this.AddCorvette.Location = new System.Drawing.Point(229, 167);
            this.AddCorvette.Name = "AddCorvette";
            this.AddCorvette.Size = new System.Drawing.Size(93, 29);
            this.AddCorvette.TabIndex = 2;
            this.AddCorvette.Text = "Корвет";
            this.AddCorvette.UseVisualStyleBackColor = true;
            this.AddCorvette.Click += new System.EventHandler(this.AddCorvette_Click);
            // 
            // AddSailboat
            // 
            this.AddSailboat.Location = new System.Drawing.Point(229, 105);
            this.AddSailboat.Name = "AddSailboat";
            this.AddSailboat.Size = new System.Drawing.Size(93, 29);
            this.AddSailboat.TabIndex = 1;
            this.AddSailboat.Text = "Парусник";
            this.AddSailboat.UseVisualStyleBackColor = true;
            this.AddSailboat.Click += new System.EventHandler(this.AddSailboat_Click);
            // 
            // AddSteamer
            // 
            this.AddSteamer.Location = new System.Drawing.Point(229, 47);
            this.AddSteamer.Name = "AddSteamer";
            this.AddSteamer.Size = new System.Drawing.Size(93, 29);
            this.AddSteamer.TabIndex = 0;
            this.AddSteamer.Text = "Пароход";
            this.AddSteamer.UseVisualStyleBackColor = true;
            this.AddSteamer.Click += new System.EventHandler(this.AddSteamer_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Information);
            this.tabPage2.Controls.Add(this.ChooseShip);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(545, 315);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Просмотреть";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Information
            // 
            this.Information.BackgroundColor = System.Drawing.SystemColors.Info;
            this.Information.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Information.Location = new System.Drawing.Point(8, 40);
            this.Information.Name = "Information";
            this.Information.Size = new System.Drawing.Size(529, 267);
            this.Information.TabIndex = 1;
            // 
            // ChooseShip
            // 
            this.ChooseShip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ChooseShip.FormattingEnabled = true;
            this.ChooseShip.Location = new System.Drawing.Point(8, 6);
            this.ChooseShip.Name = "ChooseShip";
            this.ChooseShip.Size = new System.Drawing.Size(529, 28);
            this.ChooseShip.TabIndex = 0;
            this.ChooseShip.SelectedIndexChanged += new System.EventHandler(this.ChooseShip_SelectedIndexChanged);
            // 
            // FormShip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 348);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormShip";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ship";
            this.Load += new System.EventHandler(this.FormShip_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Information)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button AddCorvette;
        private System.Windows.Forms.Button AddSailboat;
        private System.Windows.Forms.Button AddSteamer;
        private System.Windows.Forms.DataGridView Information;
        private System.Windows.Forms.ComboBox ChooseShip;
    }
}

