﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab2
{
    class Steamer : Ship
    {
        public int Efficiency { get; set; }
        public string ShaftSpeed { get; set; }

        public override string GetInfo()
        {
            return "Информация о параходе: \n" +
                    base.GetInfo() +
                    "КПД: " + Efficiency + "\n" +
                    "Частота вращения вала: " + ShaftSpeed + "\n";
        }
    }
}
