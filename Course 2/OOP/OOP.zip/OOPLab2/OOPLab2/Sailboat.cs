﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab2
{
    class Sailboat : Ship
    {
        public int NumberofSails { get; set; }
        public string Appointment { get; set; }

        public override string GetInfo()
        {
            return "Информация о паруснике: \n" +
                    base.GetInfo() +
                    "Кол-во парусов: " + NumberofSails + "\n" +
                    "По назначению: " + Appointment + "\n";
        }
    }
}
