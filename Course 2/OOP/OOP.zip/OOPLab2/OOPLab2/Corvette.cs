﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab2
{
    class Corvette : Ship
    {
        public int Ammunition { get; set;}
        public string Armament { get; set; }

        public override string GetInfo()
        {
            return "Информация о корвете: " +
                    base.GetInfo() +
                    "Боеприпасы: " + Ammunition + "\n" +
                    "Вооружение: " + Armament + "\n";
        }
    }
}
