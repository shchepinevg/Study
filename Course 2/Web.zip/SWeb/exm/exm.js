
function changeText()
{
    if ($("[name = 'gender']")[1].checked)
    {
        $('#agreementText').slideUp('fast', function() {
            $('#agreementText').prop('innerHTML', 'Я согласна с пользовательским соглашением');
        });
        $('#mailText').slideUp('fast', function() {
            $('#mailText').prop('innerHTML', 'Я согласна на почтовую рассылку');
        });

        $('#agreementText').slideDown('fast');
        $('#mailText').slideDown('fast');
    }else
    {
        $('#agreementText').slideUp('fast', function() {
            $('#agreementText').prop('innerHTML', 'Я согласен с пользовательским соглашением');
        });
        $('#mailText').slideUp('fast', function() {
            $('#mailText').prop('innerHTML', 'Я согласен на почтовую рассылку');
        });
        $('#agreementText').slideDown('fast');
        $('#mailText').slideDown('fast');
    }
}

Human = new Object();

function checkForm()
{
    Human.firstName = $("#firstNameBox").prop('value');
    Human.secondName = $("#secondNameBox").prop('value');
    Human.login = $("#loginBox").prop('value');
    Human.password = $("#passwordBox").prop('value');

    if ($("[name = 'gender']")[0].checked)
        Human.gender = "Male";
    else if ($("[name = 'gender']")[1].checked)
        Human.gender = "Female";

    Human.work = $("#workType option:selected").text();
    Human.mailAgreement = $("#mailSend").prop('checked');

    Human.Photo = $("#photoFile").prop('value');

    if (Human.firstName.length < 3 || Human.secondName < 2 || Human.login.length < 3 ||
        Human.password.length < 2 || Human.gender == null)
        alert("Неверные данные!");
    else
        sendData();
    return false;
}

function sendData()
{
    console.warn(Human.firstName + " " +  Human.secondName + " " + Human.login + " " + Human.password + " "
        + Human.gender + " " + Human.work + " " + Human.mailAgreement +  " "+ Human.Photo);
    setCookie('firstName', Human.firstName, (60*60*24*365));
    setCookie('secondName', Human.secondName, (60*60*24*365));
    setCookie('login', Human.login, (60*60*24*365));
    setCookie('password', Human.password, (60*60*24*365));
    setCookie('gender', Human.gender, (60*60*24*365));
    setCookie('work', Human.work, (60*60*24*365));
    setCookie('mailAgreement', Human.mailAgreement, (60*60*24*365));
    alert(document.cookie);
}

function buttonColor()
{
    var a = 0;
    for (var i = 0; i < 4; i++)
        if($('input')[i].value != "")
            a++;
    if ($('form').prop('elements')[4].checked || $('form').prop('elements')[5].checked)
        a++;
    if ($('form').prop('elements')[7].checked)
        a++;
    if ($('form').prop('elements')[9].checked)
        a++;
    $(".btn.btn-primary").prop('innerHTML', "Заполнено " + (a+1) + "/8 полей");

    if (a < 3)
        $(".btn.btn-primary").stop().animate({backgroundColor:'#ff0200'}, 'turtle');
    if (a > 2 && a < 7)
        $(".btn.btn-primary").stop().animate({backgroundColor:'#ee9900'}, 'turtle');
    if (a == 7) {
        $(".btn.btn-primary").stop().animate({backgroundColor:'#0fe61d'}, 'turtle');
        $(".btn.btn-primary").prop('innerHTML', 'Отправить');
    }

}

function setCookie(name, text, age)
{
    document.cookie = name + "=" + encodeURIComponent(text) + ";" + "max-age=" + age + ";";
}

function getCookie(name)
{
    var allcookies = document.cookie + ";";
    var pos = allcookies.indexOf(name);
    if (pos != 1) {
        var start = pos + name.length + 1;
        var end = allcookies.indexOf(";", start);
        var value = allcookies.substring(start, end);
        value = decodeURIComponent (value);
    }
    return value;
}

function delCookie(name)
{
    document.cookie = name + "=" + "; maxage=0;";
}

function openCookie()
{
    $("#firstNameBox").prop('value', getCookie('firstName'));
    $("#secondNameBox").prop('value', getCookie('secondName'));
    $("#loginBox").prop('value', getCookie('login'));
    $("#passwordBox").prop('value', getCookie('password'));
    if (getCookie('gender') == 'Male')
        $("[name = 'gender']")[0].checked = true;
    else if (getCookie('gender') == 'Female')
        $("[name = 'gender']")[1].checked = true;

    $("#workType").val(getCookie('work'));
    $("#mailSend").prop('checked', getCookie('mailAgreement'));
}

