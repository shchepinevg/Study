var d = new Date();
var group = {name: "KI00-00", numberOfStudents: 0, averageMark: 0};

group.name = "KI16-16b";
group.numberOfStudents = 28;
group["averageMark"] = 4.2;

console.log(d.getDate());
console.log(d.getMonth() + 1);
console.log(d.getFullYear());
console.log('\n');

function Group(name, numberOfStudents, averageMark) {
	this.name = name;
	this.numberOfStudents = numberOfStudents;
	this.averageMark = averageMark;
	this.Print = function() {
		console.log(this.name);
		console.log(this.numberOfStudents);
		console.log(this.averageMark);
		console.log('\n');
	}
	return 0;
}

var gr = new Group("KI17-17b", 30, 4.1);
gr.Print();

Date.prototype.learnAge = function(date, month, year) {
	month--;
	var today = new Date();
	var age = today.getFullYear() - year;
    var m = today.getMonth() - month;
    if (m < 0 || (m === 0 && today.getDate() < date)) { 
          age--;
    }
	return age;
}

var date = new Date();
console.log(date.learnAge(29, 05, 1999));
