var car = { speed: null, left: null, top: null, directionX: 1, directionY: 1 };
var car2 = { speed: null, left: null, top: null, directionX: 1, directionY: 1 };
var stop = { speed: 0, left: null,  top: null, direction: 1};

function changeSpeed()
{
    car.speed = parseInt($("#speedcar option:selected").prop('text'));
	car2.speed = parseInt($("#speedcar option:selected").prop('text'));
    stop.speed = parseInt($("#speedstop option:selected").prop('text'));
}

function gameLoop() {
    if (car) {
        movecar();
		movecar2();
        movestop();
    }
}

function startGame() {
    if ($("#sizeW").val() != "" && $("#sizeH").val() != "" && $("#sizeW").val() <= 200 && $("#sizeW").val() >= 50 && $("#sizeH").val() <= 200 && $("#sizeH").val() >= 50) {
        console.log("Start!");
        // clearInterval(gameLoop);
        console.log(parseInt($("#car").css("left")))
        $("#stop").css("width", $("#sizeW").val());
        $("#stop").css("height", $("#sizeH").val());
        car.speed = parseInt($("#speedcar option:selected").prop('text'));
		if ($("#vector1 option:selected").prop('text') == "Северо-восток") {
			car.directionX = 1;
			car.directionY = 1;
		}
		if ($("#vector1 option:selected").prop('text') == "Юго-восток") {
			car.directionX = 1;
			car.directionY = -1;
		}
		if ($("#vector1 option:selected").prop('text') == "Юго-запад") {
			car.directionX = -1;
			car.directionY = -1;
			$("#car").attr("src", "carRev.png")
		}
		if ($("#vector1 option:selected").prop('text') == "Северо-запад") {
			car.directionX = -1;
			car.directionY = 1;
			$("#car").attr("src", "carRev.png")
		}
		car2.speed = parseInt($("#speedcar2 option:selected").prop('text'));
		if ($("#vector2 option:selected").prop('text') == "Северо-восток") {
			car2.directionX = 1;
			car2.directionY = 1;
		}
		if ($("#vector2 option:selected").prop('text') == "Юго-восток") {
			car2.directionX = 1;
			car2.directionY = -1;
		}
		if ($("#vector2 option:selected").prop('text') == "Юго-запад") {
			car2.directionX = -1;
			car2.directionY = -1;
			$("#car2").attr("src", "car2Rev.png")
		}
		if ($("#vector2 option:selected").prop('text') == "Северо-запад") {
			car2.directionX = -1;
			car2.directionY = 1;
			$("#car2").attr("src", "car2Rev.png")
		}
        stop.speed = parseInt($("#speedstop option:selected").prop('text'));
        car.left = parseInt($("#car").css("left"));
        car.top = parseInt($("#car").css("top"));
		car2.left = parseInt($("#car2").css("left"));
        car2.top = parseInt($("#car2").css("top"));
        stop.left = parseInt($("#stop").css("left"));
        stop.top = parseInt($("#stop").css("top")); 
        setInterval(gameLoop, 1000 / 60);
        $("#startG").prop('disabled', true);
        $("#sizeW").prop('disabled', true);
        $("#sizeH").prop('disabled', true);
    }
    else
    { alert("Введены некорректные данные!"); }
};


function movestop() {
	if (stop.direction == 1) {
		if (stop.top > 0) {
			stop.top -= stop.speed;
			$("#stop").css("top", stop.top);
		}
        else stop.direction *= -1;
	}
	
	if (stop.direction == -1) {
		if (stop.top+parseInt($("#stop").css("height")) < parseInt($("#game").css("height"))) {
			stop.top += stop.speed;
			$("#stop").css("top", stop.top);
        }
		else stop.direction *= -1;
	}        
}

function movecar() {
    if (car.top + car.speed > parseInt($("#game").css("height")) - parseInt($("#car").css("width")) || car.top - car.speed < 0) {
        car.directionY *= -1;
    }

    if ((car.left - car.speed < 0) || (car.left + car.speed > parseInt($("#game").css("width")) - parseInt($("#car").css("width")))) {
        car.directionX *= -1;
		Reverse();
    }

    if (car.directionX == 1 && car.directionY == 1) {
        if (car.left+parseInt($("#car").css("width")) + car.speed >= stop.left && car.left < stop.left && car.top > stop.top && car.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car.directionX *= -1;
			Reverse();
        }
        if (car.top - car.speed <= stop.top + parseInt($("#stop").css("height")) && car.top >= stop.top + parseInt($("#stop").css("height")) && car.left+parseInt($("#car").css("width")) > stop.left && car.left < stop.left + parseInt($("#stop").css("width")))
        {
            car.directionY *= -1; 
        }
        car.left = car.left + car.speed;
        car.top = car.top - car.speed;
        $("#car").css("left", car.left);
        $("#car").css("top", car.top);
    }

    if (car.directionX == 1 && car.directionY == -1) {
        if (car.left+parseInt($("#car").css("width")) + car.speed >= stop.left && car.left < stop.left && car.top > stop.top && car.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car.directionX *= -1;
			Reverse();
        }
        if (car.top+parseInt($("#car").css("height")) + car.speed >= stop.top && car.top < stop.top && car.left+parseInt($("#car").css("width")) > stop.left && car.left < stop.left + parseInt($("#stop").css("width")))
        {
            car.directionY *= -1;         
        }
        car.left = car.left + car.speed;
        car.top = car.top + car.speed;
        $("#car").css("left", car.left);
        $("#car").css("top", car.top);
    }

    if (car.directionX == -1 && car.directionY == 1) {
        if (car.left - car.speed <= stop.left + parseInt($("#stop").css("width")) && car.left > stop.left && car.top > stop.top && car.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car.directionX *= -1;
			Reverse();
        }
        if (car.top - car.speed <= stop.top + parseInt($("#stop").css("height")) && car.top >= stop.top + parseInt($("#stop").css("height")) && car.left+parseInt($("#car").css("width")) > stop.left && car.left < stop.left + parseInt($("#stop").css("width")))
        {
            car.directionY *= -1; 
        }
        car.left = car.left - car.speed;
        car.top = car.top - car.speed;
        $("#car").css("left", car.left);
        $("#car").css("top", car.top);
    }

    if (car.directionX == -1 && car.directionY == -1) {
        if (car.left - car.speed <= stop.left + parseInt($("#stop").css("width"))  && car.left >= stop.left+parseInt($("#stop").css("width")) && car.top+parseInt($("#car").css("width")) > stop.top && car.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car.directionX *= -1;
			Reverse();
        }
        if (car.top+parseInt($("#car").css("height")) + car.speed >= stop.top && car.top < stop.top && car.left+parseInt($("#car").css("width")) >= stop.left && car.left <= stop.left + parseInt($("#stop").css("width")))
        {
            car.directionY *= -1;         
        }
        car.left = car.left - car.speed;
        car.top = car.top + car.speed;
        $("#car").css("left", car.left);
        $("#car").css("top", car.top);
    }
}

function movecar2() {
    if (car2.top + car2.speed > parseInt($("#game").css("height")) - parseInt($("#car2").css("width")) || car2.top - car2.speed < 0) {
        car2.directionY *= -1;
    }

    if ((car2.left - car2.speed < 0) || (car2.left + car2.speed > parseInt($("#game").css("width")) - parseInt($("#car2").css("width")))) {
        car2.directionX *= -1;
		Reverse2();
    }

    if (car2.directionX == 1 && car2.directionY == 1) {
        if (car2.left+parseInt($("#car2").css("width")) + car2.speed >= stop.left && car2.left < stop.left && car2.top > stop.top && car2.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car2.directionX *= -1;
			Reverse2();
        }
        if (car2.top - car2.speed <= stop.top + parseInt($("#stop").css("height")) && car2.top >= stop.top + parseInt($("#stop").css("height")) && car2.left+parseInt($("#car2").css("width")) > stop.left && car2.left < stop.left + parseInt($("#stop").css("width")))
        {
            car2.directionY *= -1; 
        }
        car2.left = car2.left + car2.speed;
        car2.top = car2.top - car2.speed;
        $("#car2").css("left", car2.left);
        $("#car2").css("top", car2.top);
    }

    if (car2.directionX == 1 && car2.directionY == -1) {
        if (car2.left+parseInt($("#car2").css("width")) + car2.speed >= stop.left && car2.left < stop.left && car2.top > stop.top && car2.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car2.directionX *= -1;
			Reverse2();
        }
        if (car2.top+parseInt($("#car2").css("height")) + car2.speed >= stop.top && car2.top < stop.top && car2.left+parseInt($("#car2").css("width")) > stop.left && car2.left < stop.left + parseInt($("#stop").css("width")))
        {
            car2.directionY *= -1;         
        }
        car2.left = car2.left + car2.speed;
        car2.top = car2.top + car2.speed;
        $("#car2").css("left", car2.left);
        $("#car2").css("top", car2.top);
    }

    if (car2.directionX == -1 && car2.directionY == 1) {
        if (car2.left - car2.speed <= stop.left + parseInt($("#stop").css("width")) && car2.left > stop.left && car2.top > stop.top && car2.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car2.directionX *= -1;
			Reverse2();
        }
        if (car2.top - car2.speed <= stop.top + parseInt($("#stop").css("height")) && car2.top >= stop.top + parseInt($("#stop").css("height")) && car2.left+parseInt($("#car2").css("width")) > stop.left && car2.left < stop.left + parseInt($("#stop").css("width")))
        {
            car2.directionY *= -1; 
        }
        car2.left = car2.left - car2.speed;
        car2.top = car2.top - car2.speed;
        $("#car2").css("left", car2.left);
        $("#car2").css("top", car2.top);
    }

    if (car2.directionX == -1 && car2.directionY == -1) {
        if (car2.left - car2.speed <= stop.left + parseInt($("#stop").css("width"))  && car2.left >= stop.left+parseInt($("#stop").css("width")) && car2.top+parseInt($("#car2").css("width")) > stop.top && car2.top < parseInt($("#stop").css("height")) + stop.top) 
        {
            car2.directionX *= -1;
			Reverse2();
        }
        if (car2.top+parseInt($("#car2").css("height")) + car2.speed >= stop.top && car2.top < stop.top && car2.left+parseInt($("#car2").css("width")) >= stop.left && car2.left <= stop.left + parseInt($("#stop").css("width")))
        {
            car2.directionY *= -1;         
        }
        car2.left = car2.left - car2.speed;
        car2.top = car2.top + car2.speed;
        $("#car2").css("left", car2.left);
        $("#car2").css("top", car2.top);
    }
}

function Reverse() {
	if ($("#car").attr("src") == "car.png")
		$("#car").attr("src", "carRev.png")
	else $("#car").attr("src", "car.png")
}

function Reverse2() {
	if ($("#car2").attr("src") == "car2.png")
		$("#car2").attr("src", "car2Rev.png")
	else $("#car2").attr("src", "car2.png")
}


