var user = new Object();

function send() {
	user.Name = document.getElementById("nameBox").value;
	user.Comment = document.getElementById("commentBox").value;
	user.Mail = document.getElementById("mailBox").value;
	
	if (document.getElementsByName("check")[0].checked)
		user.checkMail = true;
	else if (document.getElementsByName("check")[1].checked)
		user.checkMail = false;
	
	if (user.Name.length == 0 || user.Comment.length == 0 || user.Mail.length == 0) 
		alert("Заполните все поля");
	else {
		sendToConsole();
		document.getElementById("nameBox").value = "";
		document.getElementById("commentBox").value = "";
		document.getElementById("mailBox").value = "";
	}
}

function sendToConsole() {
	if (user.Comment.length > 10)
		user.Comment = user.Comment.substr(0, 10) + "...";

	console.log("Имя: " + user.Name + "\nОтзыв: " + user.Comment + "\nПочта: " + user.Mail + "\nРассылка: " + user.checkMail + "\n");
}

function activeRadio() {
	document.getElementsByName("check")[0].disabled = 0;
	document.getElementsByName("check")[1].disabled = 0;
	
	if (document.getElementById("mailBox").value.length == 0) {
		document.getElementsByName("check")[0].disabled = 1;
		document.getElementsByName("check")[1].disabled = 1;
	}
		
}

function buttonStyle() {
	var k = 0;
	for (var i = 0; i < 3; i++)
        if(document.forms[0].elements[i].value != "")
            k++;
		
	switch(k) {
		case 1:
			document.getElementsByClassName("btn btn-primary")[0].style.backgroundColor = '#ff0200';
		break;
		
		case 2:
			document.getElementsByClassName("btn btn-primary")[0].style.backgroundColor = '#ee9900';
		break;
		
		case 3:
			document.getElementsByClassName("btn btn-primary")[0].style.backgroundColor = '#0fe61d';
		break;
		
		default:
			break;
	}
}


