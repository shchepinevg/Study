$("#adidas").click(adidasshow);
$("#newbalance").click(newbalanceshow);
$("#nike").click(nikeshow);

$.fx.speeds.fast = 300;
$.fx.speeds.myspeed = 900;

function adidasshow() {
	$("#pAdidas").slideToggle('fast');
};

function newbalanceshow() {
	$(".pNewBalance").slideToggle('fast');
};

function nikeshow() {
	$("p[name='pNike']").slideToggle('fast');
};

$(".boots").animate({
	marginLeft: '+=370',
},
	'myspeed',
	function () {
		$("#btnleft").css("visibility", "visible");
		$("#btnright").css("visibility", "visible");
	}
);