$("input[type='submit']").click(send);
$("#mailBox").keydown(activeRadio);
$(document).keydown(buttonStyle);
$("input[type='button']").click(delAllCookie);

var user = new Object();

function send() {
	user.Name = $("#nameBox").val();
	user.Comment = $("#commentBox").val();
	user.Mail = $("#mailBox").val();
	
	if ($("input[name='check']").get(0).checked)
		user.checkMail = true;
	else if ($("input[name='check']").get(1).checked)
		user.checkMail = false;
	
	if (user.Name.length == 0 || user.Comment.length == 0 || user.Mail.length == 0) 
		alert("Заполните все поля");
	else {
		sendToConsole();		
		setCookie("Name", user.Name, (60*60*24*365));
		setCookie("Comment", user.Comment, (60*60*24*365));
		setCookie("Mail", user.Mail, (60*60*24*30));
		setCookie("checkMail", user.checkMail, (60*60*24*365));
		//event.preventDefault();
	}
}

function sendToConsole() {
	if (user.Comment.length > 10)
		user.Comment = user.Comment.substr(0, 10) + "...";

	console.log("Имя: " + user.Name + "\nОтзыв: " + user.Comment + "\nПочта: " + user.Mail + "\nРассылка: " + user.checkMail + "\n");
}

function activeRadio() {
	console.log();
	$("input[name='check']").get(0).disabled = 0;
	$("input[name='check']").get(1).disabled = 0;
	
	if ($("#mailBox").val().length == 0) {
		$("input[name='check']").get(0).disabled = 1;
		$("input[name='check']").get(1).disabled = 1;
	}
		
}

function buttonStyle() {
	var k = 0;
	for (var i = 0; i < 3; i++) {
		console.log($(".qqq").val());
        if($(".qqq")[i] != "")   
            k++;
	}
	switch(k) {
		case 1:
			$(".btn.btn-primary").css('background', '#ff0200');
		break;
		
		case 2:
			$(".btn.btn-primary").css('background', '#ee9900');
		break;
		
		case 3:
			$(".btn.btn-primary").css('background', '#0fe61d');
		break;
		
		default:
			break;
	}
}

function setCookie(name, text, age) {
	document.cookie = name + "=" + encodeURIComponent(text) + ";" + "max-age=" + age;
}

function getCookie(name) {
    var allcookies = document.cookie;
    var pos = allcookies.indexOf(name + "=");
    if (pos != 1) {
        var start = pos + name.length + 1;
        var end = allcookies.indexOf(";", start);
        if (end == 1)
            end = allcookies.length;
        var value = decodeURIComponent(allcookies.substring(start, end));
    }
    return value;
}

function delCookie(name) {
    document.cookie = name + "=" + "; maxage=0;";
}

function openCookie() {
	$("#nameBox").val(getCookie("Name"));
	$("#commentBox").val(getCookie("Comment"));
	$("#mailBox").val(getCookie("Mail"));
	if (getCookie("checkMail") == true || getCookie("checkMail") == "" ){
		$("input[name='check']").get(0).checked = true;
	}
	else $("input[name='check']").get(1).checked = true;
}

function delAllCookie() {
	delCookie("Name");
	delCookie("Comment");
	delCookie("Mail");
	delCookie("checkMail");
	alert("Куки были очищены");
}


