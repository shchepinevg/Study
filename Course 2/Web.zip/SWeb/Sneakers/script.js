// function task()
// {
    // console.warn("Ссылки");
    // for (var i = 0; i < document.links.length; i++)
        // console.log((i + 1), document.links[i]);

    // console.warn("Якори");
    // for (var i = 0; i < document.anchors.length; i++)
        // console.log((i + 1), document.anchors[i]);
	
	    // console.warn("Изображения");
    // for (var i = 0; i < document.images.length; i++)
        // console.log((i + 1), document.images[i]);
// }

// function headMouse()
// {
    // console.warn("Указатель наведен на заголовок\n");
// }

// document.getElementById("content").onmousedown = function() {
	
	// console.warn("Высказывание Адольфа Даслера\n");
// }

// document.getElementById("autor").onmousedown = function() {
	
	// console.warn("Автора высказывания\n");
// }

// document.getElementById("date").onmousedown = function() {
	
	// console.warn("Год высказывания\n");
// }

var array = ["images/boots.png", "images/jordan1.png", "images/jordan2.png", "images/jordan3.png"];
var i = 0;

function prevImage()
{
    i--;
    if (i < 0)
        i = array.length - 1;
    document.images[0].src = array[i];
}

function nextImage()
{
    i++;
    if (i == array.length)
        i = 0;
    document.images[0].src = array[i];
}

