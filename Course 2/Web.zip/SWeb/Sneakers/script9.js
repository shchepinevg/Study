document.getElementsByTagName("h2")[1].addEventListener("click", clickOnAdidas, false);
document.getElementsByTagName("h2")[2].addEventListener("click", clickOnNewBalance, false);
document.getElementsByTagName("h2")[3].addEventListener("click", clickOnNike, false);

function clickOnAdidas() {
	var x = document.getElementById("divAdidas").childElementCount;
	x === 2 ? removeParagraphAdidas() : addParagraphAdidas();
}

function removeParagraphAdidas() {
	var elem = document.getElementById("pAdidas");
	parentElem = document.getElementById("divAdidas");
	parentElem.removeChild(elem);
}

function addParagraphAdidas() {
	var text = 'Company "Adidas", which are interested to get acquainted to many, appeared in the distant 1920. The word, which became the name of the company "Adidas", came from the name of its founder, Adolf Dassler, having absorbed the initial syllables directly name and surname. Company "Adidas" produced and produces at the present day shoes, apparel and gear for sports activities. It is the largest company in Germany, whose Director General today is Herbert Hainer.';
	var elem = document.createElement("p");
	elem.id = "pAdidas";
	elem.innerHTML = text;
	
	var parentElem = document.getElementById("divAdidas");
	parentElem.appendChild(elem);
}

//------------------------------------------------------------

function clickOnNewBalance() {
	var x = document.getElementsByClassName("divNewBalance")[0].childElementCount;
	x === 2 ? removeParagraphNewBalance() : addParagraphNewBalance();
}

function removeParagraphNewBalance() {
	var elem = document.getElementsByClassName("pNewBalance")[0];
	parentElem = document.getElementsByClassName("divNewBalance");
	parentElem[0].removeChild(elem);
}

function addParagraphNewBalance() {
	var text = 'The story of New Balance begins in 1906 in the United States in Belmont, where 33-year-old emigrant from England William Riley he founded a laboratory for the development and production of corrective devices. Watching a chicken walking in the garden, Riley draws attention to its exceptional stability and excellent balance when walking due to the structure of the paw, having three points of support. This idea soon embodied them in the construction of the supporting system for shoes: he develops a special supinator, which creates a support of the heel part of the leg at three points by analogy with the chicken foot. This technology brings Riley recognition, and the firm gets its first official name — New Balance Arch company. In 1938 Riley develops and produces the first new Balance running shoes for the local sports club. In 1940, for the first time participate in the competition, after which the company began producing footwear for athletes involved in not only running, but also baseball, basketball, tennis and Boxing.';
	var elem = document.createElement("p");
	elem.className = "pNewBalance";
	elem.innerHTML = text;
	
	var parentElem = document.getElementsByClassName("divNewBalance");
	parentElem[0].appendChild(elem);
}

//------------------------------------------------------------

function clickOnNike() {
	var x = document.getElementsByName("divNike")[0].childElementCount;
	x === 2 ? removeParagraphNike() : addParagraphNike();
}

function removeParagraphNike() {
	var elem = document.getElementsByName("pNike")[0];
	parentElem = document.getElementsByName("divNike");
	parentElem[0].removeChild(elem);
}

function addParagraphNike() {
	var text = 'The company was founded in 1964 by Phil knight, a mid-distance runner on the University of Oregon team, and his coach bill Bowerman[en]. At first it was called Blue Ribbon Sports and specialized in order shoes in Asian countries and their subsequent sale on the American market. Investing in the case for $ 500, knight and Bowerman ordered 300 pairs of sneakers from a Japanese company Onitsuka Tiger (now ASICS). The company is first self-developed product — released in 1971 Nike sneakers with wafer-like design soles, the idea of which bauerman learned from his wife, or rather from her waffle maker. In 1978, Blue Ribbon Sports was officially renamed Nike.';
	var elem = document.createElement("p");
	elem.setAttribute("name", "pNike");
	elem.innerHTML = text;
	
	var parentElem = document.getElementsByName("divNike");
	parentElem[0].appendChild(elem);
}
