function ButtonClick(){
    var sumOut = document.getElementById("Sum"),
        averageOut = document.getElementById("Average"),
        countChangesOut = document.getElementById("CountChanges");
    var text = document.getElementById("arrayInput").value.trim().split(" ");
    var array = new Array();
	
    for (var i = 0; i < text.length; i++)
        if (!isNaN(parseInt(text[i])))
            array.push(parseInt(text[i]));
		
	if (array.length != 0) {
        sumOut.textContent = "Сумма элементов последовательности: " + arraySum(array);
		averageOut.textContent = "Cреднее арифметическое элементов последовательности: " + average(array);
		countChangesOut.textContent = "Количество сменяемости знака в последовательности: " + countChanges(array); 
    }
	else {
        sumOut.textContent = "Сумма элементов последовательности: Ошибка";
        averageOut.textContent = "Cреднее арифметическое элементов последовательности: Ошибка";
        countChangesOut.textContent = "Количество сменяемости знака в последовательности: Ошибка";
    } 
}

function arraySum(array){
	var sum = 0;
	for (var i = 0; i < array.length; i++){
		sum += array[i];
	}
	return sum
}

function average(array){
	return (arraySum(array) / array.length).toFixed(2);
}

function countChanges(array){
	var k = 0;
	for (var i = 0; i < array.length - 1; i++){
		if ((array[i] >= 0 && array[i + 1] < 0) || (array[i] < 0 && array[i + 1] > 0))
			k++;	
	}
	return k;
}